<?php
// ===================== API settings =====================
// TMDb key (for movies) - get one at https://www.themoviedb.org/settings/api
define('TMDB_API_KEY', 'f5c3a41b691a4699ab801530a50d5f40');
define('TMDB_BASE_URL', 'https://api.themoviedb.org/3');
define('TMDB_IMAGE_URL', 'https://image.tmdb.org/t/p/w500');

// RAWG API (games) - https://rawg.io/apidocs
define('RAWG_API_KEY', 'ecb4dfa6b47b42239c6f329dd0ddffb9');
define('RAWG_BASE_URL', 'https://api.rawg.io/api');

// ===================== Debugging =====================
// Turn this on to log every external API request/response to debug.log
// (in the project root) so it's possible to see exactly what came back.
define('DEBUG_EXTERNAL_APIS', true);
define('DEBUG_LOG_PATH', __DIR__ . '/../debug.log');

// ===================== Database =====================
// The database is now a single SQLite file inside the project:
//   data/media.sqlite          <- the database (visible, copyable)
//   data/backups/              <- automatic + manual backups
// Manage / restore backups from:  http://localhost/media-tracker/backup.php
define('DATA_DIR', __DIR__ . '/../data');
define('DB_FILE', DATA_DIR . '/media.sqlite');
define('BACKUP_DIR', DATA_DIR . '/backups');

// Optional: ALSO copy every backup to another folder/drive (e.g. 'D:/Backups/media'
// or a Dropbox/OneDrive folder). Leave empty to disable. A second location is the
// real protection against disk failure or deleting the project folder.
define('BACKUP_MIRROR_DIR', '');

// Old MySQL settings: only used once, to copy existing data into SQLite the first
// time the app runs (or from backup.php -> "Import from old MySQL").
define('LEGACY_MYSQL_IMPORT', true);
define('DB_HOST', 'localhost');
define('DB_NAME', 'media_tracker');
define('DB_USER', 'root');
define('DB_PASS', '');

require_once __DIR__ . '/../includes/db.php';
