<?php
// Creates/checks the database (data/media.sqlite). Safe to run any time; it never deletes data.
// (Also happens automatically on first page load, so running this is optional.)
require_once __DIR__ . '/config/config.php';
try {
    $pdo = getDB();
    $n = (int)$pdo->query('SELECT COUNT(*) FROM media_items')->fetchColumn();
    echo "<div style='font-family:sans-serif; padding:40px; background:#f0fdf4; color:#166534;'>";
    echo "<h2>&#9989; Database is ready ($n items).</h2>";
    echo "<p>File: <code>data/media.sqlite</code></p>";
    echo "<p><a href='index.php'>Homepage</a> &middot; <a href='backup.php'>Backups</a></p>";
    echo "</div>";
} catch (Throwable $e) {
    echo "<div style='font-family:sans-serif; padding:40px; background:#fef2f2; color:#991b1b;'>";
    echo "<h2>&#10060; Error:</h2><p>" . htmlspecialchars($e->getMessage()) . "</p></div>";
}
