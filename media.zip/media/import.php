<?php
require_once __DIR__ . '/config/config.php';
?>
<!DOCTYPE html>
<html lang="en" dir="ltr" class="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Import from Excel | My Archive</title>
<script>
  (function() {
    var t = localStorage.getItem('mt-theme') || 'dark';
    if (t === 'light') document.documentElement.classList.remove('dark');
    else document.documentElement.classList.add('dark');
  })();
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/3.4.1/tailwind.min.css"></script>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<script>
  tailwind.config = {
    darkMode: 'class',
    theme: {
      extend: {
        fontFamily: { vazir: ['Vazirmatn', 'sans-serif'], mono: ['Space Mono', 'monospace'] },
        colors: { ink: '#0f0e0c', panel: '#1a1815', amber: '#e0a458', rust: '#c1502e', bone: '#e8e2d4' }
      }
    }
  }
</script>
<style>
  @font-face {
    font-family: 'Mikhak';
    src: url('assets/fonts/Mikhak-SemiBold.ttf') format('truetype');
    font-weight: 600;
    font-style: normal;
    font-display: swap;
  }
  body { font-family: 'Mikhak', 'Vazirmatn', sans-serif; }
  .mono { font-family: 'Space Mono', monospace; }
  ::-webkit-scrollbar { width: 8px; }
  ::-webkit-scrollbar-track { background: #1a1815; }
  ::-webkit-scrollbar-thumb { background: #e0a458; border-radius: 4px; }

  html:not(.dark) body { background: #f5f2ea; color: #241f16; }
  html:not(.dark) header { background: rgba(245,242,234,0.9); border-color: rgba(36,31,22,0.1); }
  html:not(.dark) .bg-panel { background: #ffffff; border-color: rgba(36,31,22,0.1); }
  html:not(.dark) .bg-ink { background: #eee9dd; }
  html:not(.dark) .border-white\/10 { border-color: rgba(36,31,22,0.1); }
  html:not(.dark) .border-white\/15 { border-color: rgba(36,31,22,0.15); }
  html:not(.dark) .text-bone { color: #241f16; }
  html:not(.dark) .text-bone\/80 { color: rgba(36,31,22,0.8); }
  html:not(.dark) .text-bone\/60 { color: rgba(36,31,22,0.6); }
  html:not(.dark) .text-bone\/50 { color: rgba(36,31,22,0.55); }
  html:not(.dark) .text-bone\/40 { color: rgba(36,31,22,0.45); }
  html:not(.dark) .text-bone\/30 { color: rgba(36,31,22,0.35); }
  html:not(.dark) ::-webkit-scrollbar-track { background: #eee9dd; }
  html:not(.dark) input::placeholder { color: rgba(36,31,22,0.4); opacity: 1; }

  .drop-zone.drag-over { border-color: #e0a458; background: rgba(224,164,88,0.08); }
  .progress-bar-fill { transition: width 0.3s ease; }
</style>
</head>
<body class="bg-ink text-bone min-h-screen transition-colors duration-300">

<header class="border-b border-white/10 sticky top-0 bg-ink/90 backdrop-blur-md z-40">
  <div class="max-w-3xl mx-auto px-6 py-5 flex items-center justify-between">
    <div class="flex items-center gap-3">
      <a href="index.php" class="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center hover:border-amber transition-colors">←</a>
      <div>
        <h1 class="text-xl font-extrabold tracking-tight">Import from Excel</h1>
        <p class="mono text-[11px] text-bone/40 tracking-widest">BULK IMPORT</p>
      </div>
    </div>
    <button id="themeToggle" class="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center text-lg hover:border-amber transition-colors">
      <span id="themeIcon">🌙</span>
    </button>
  </div>
</header>

<div class="max-w-3xl mx-auto px-6 py-10">

  <!-- Step 1: Upload -->
  <section id="uploadSection" class="bg-panel border border-white/10 rounded-2xl p-6 mb-6">
    <h2 class="text-lg font-bold mb-1">1. Choose your file</h2>
    <p class="text-bone/50 text-sm mb-5">A .xlsx or .csv file. The first row should be column headers (e.g. Title, Status/Notes).</p>

    <label id="dropZone" for="fileInput" class="drop-zone cursor-pointer flex flex-col items-center justify-center gap-2 border-2 border-dashed border-white/15 rounded-xl py-12 hover:border-amber/50 transition-colors">
      <span class="text-4xl">📄</span>
      <span class="font-bold text-sm">Click to choose a file, or drag it here</span>
      <span class="text-bone/40 text-xs">.xlsx or .csv</span>
      <input type="file" id="fileInput" accept=".xlsx,.csv" class="hidden">
    </label>

    <div id="uploadStatus" class="mt-4 text-sm hidden"></div>
  </section>

  <!-- Step 2: Pick type + preview -->
  <section id="mapSection" class="bg-panel border border-white/10 rounded-2xl p-6 mb-6 hidden">
    <h2 class="text-lg font-bold mb-1">2. Confirm and import</h2>
    <p class="text-bone/50 text-sm mb-5">The first column is used as the title, the second as your notes. Just tell us the type.</p>

    <div class="mb-5">
      <label class="block text-xs text-bone/50 mb-1.5">Every row in this file is a...</label>
      <div class="flex gap-3">
        <label class="flex-1 flex items-center gap-2 bg-ink border border-white/15 rounded-xl px-4 py-2.5 cursor-pointer has-[:checked]:border-amber">
          <input type="radio" name="singleType" value="movie" checked> <span>🎬 Movie</span>
        </label>
        <label class="flex-1 flex items-center gap-2 bg-ink border border-white/15 rounded-xl px-4 py-2.5 cursor-pointer has-[:checked]:border-amber">
          <input type="radio" name="singleType" value="game"> <span>🎮 Game</span>
        </label>
      </div>
    </div>

    <div>
      <p class="text-xs text-bone/50 mb-2">Preview (first 5 rows)</p>
      <div class="overflow-x-auto rounded-xl border border-white/10">
        <table class="w-full text-sm">
          <thead id="previewHead" class="bg-ink text-bone/60 text-xs"></thead>
          <tbody id="previewBody"></tbody>
        </table>
      </div>
      <p id="rowCountLabel" class="mono text-xs text-bone/40 mt-2"></p>
    </div>

    <button id="startImportBtn" class="mt-5 w-full bg-amber text-ink font-bold rounded-xl px-6 py-3 hover:bg-amber/90 transition-colors">
      Start Import
    </button>
  </section>

  <!-- Step 3: Progress -->
  <section id="progressSection" class="bg-panel border border-white/10 rounded-2xl p-6 mb-6 hidden">
    <h2 class="text-lg font-bold mb-1">3. Importing...</h2>
    <p id="progressLabel" class="text-bone/50 text-sm mb-4">Starting...</p>

    <div class="w-full h-3 bg-ink rounded-full overflow-hidden border border-white/10">
      <div id="progressBarFill" class="progress-bar-fill h-full bg-amber" style="width: 0%"></div>
    </div>

    <div class="grid grid-cols-3 gap-3 mt-5 mono text-center text-sm">
      <div>
        <div id="countAdded" class="text-green-400 text-xl font-bold">0</div>
        <div class="text-bone/40 text-[10px] tracking-wider">ADDED</div>
      </div>
      <div>
        <div id="countSkipped" class="text-amber text-xl font-bold">0</div>
        <div class="text-bone/40 text-[10px] tracking-wider">SKIPPED</div>
      </div>
      <div>
        <div id="countFailed" class="text-rust text-xl font-bold">0</div>
        <div class="text-bone/40 text-[10px] tracking-wider">FAILED</div>
      </div>
    </div>

    <div id="importLog" class="mt-5 max-h-64 overflow-y-auto text-xs mono border border-white/10 rounded-xl divide-y divide-white/5"></div>

    <a id="doneBtn" href="index.php" class="mt-5 hidden w-full text-center bg-amber text-ink font-bold rounded-xl px-6 py-3 hover:bg-amber/90 transition-colors">
      Done — Go to Archive
    </a>
  </section>

</div>

<script>
// ===== Theme (shared with index.php) =====
const html = document.documentElement;
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
function applyTheme(theme) {
  if (theme === 'light') { html.classList.remove('dark'); themeIcon.textContent = '☀️'; }
  else { html.classList.add('dark'); themeIcon.textContent = '🌙'; }
}
applyTheme(localStorage.getItem('mt-theme') || 'dark');
themeToggle.addEventListener('click', () => {
  const next = html.classList.contains('dark') ? 'light' : 'dark';
  applyTheme(next);
  localStorage.setItem('mt-theme', next);
});

// ===== Elements =====
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const uploadStatus = document.getElementById('uploadStatus');
const uploadSection = document.getElementById('uploadSection');
const mapSection = document.getElementById('mapSection');
const progressSection = document.getElementById('progressSection');

const previewHead = document.getElementById('previewHead');
const previewBody = document.getElementById('previewBody');
const rowCountLabel = document.getElementById('rowCountLabel');
const startImportBtn = document.getElementById('startImportBtn');

const progressLabel = document.getElementById('progressLabel');
const progressBarFill = document.getElementById('progressBarFill');
const countAdded = document.getElementById('countAdded');
const countSkipped = document.getElementById('countSkipped');
const countFailed = document.getElementById('countFailed');
const importLog = document.getElementById('importLog');
const doneBtn = document.getElementById('doneBtn');

let parsedHeader = [];
let parsedRows = [];

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function showUploadStatus(msg, isError) {
  uploadStatus.classList.remove('hidden');
  uploadStatus.className = 'mt-4 text-sm ' + (isError ? 'text-rust' : 'text-amber');
  uploadStatus.textContent = msg;
}

// ===== File selection (click or drag/drop) =====
dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  if (e.dataTransfer.files.length) {
    fileInput.files = e.dataTransfer.files;
    handleFile(e.dataTransfer.files[0]);
  }
});
fileInput.addEventListener('change', () => {
  if (fileInput.files.length) handleFile(fileInput.files[0]);
});

async function handleFile(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (!['xlsx', 'csv'].includes(ext)) {
    showUploadStatus('⚠️ Please choose a .xlsx or .csv file.', true);
    return;
  }

  showUploadStatus('⏳ Reading "' + file.name + '"...', false);

  const formData = new FormData();
  formData.append('file', file);

  try {
    const res = await fetch('api/parse-excel.php', { method: 'POST', body: formData });
    const data = await res.json();

    if (!data.success) {
      showUploadStatus('⚠️ ' + (data.message || 'Could not read the file.'), true);
      return;
    }

    parsedHeader = data.header;
    parsedRows = data.rows;
    showUploadStatus('✅ Loaded ' + data.row_count + ' row(s) from "' + file.name + '".', false);
    setupMapping();
  } catch (err) {
    showUploadStatus('⚠️ Could not reach the server.', true);
  }
}

// ===== Step 2: type selection + preview =====

function setupMapping() {
  mapSection.classList.remove('hidden');

  document.querySelectorAll('input[name="singleType"]').forEach(r => r.addEventListener('change', renderPreview));

  renderPreview();
  mapSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderPreview() {
  const singleType = document.querySelector('input[name="singleType"]:checked')?.value || 'movie';
  const typeLabel = singleType === 'movie' ? '🎬 Movie' : '🎮 Game';

  previewHead.innerHTML = `<tr>
    <th class="text-left px-3 py-2 font-bold">Title</th>
    <th class="text-left px-3 py-2 font-bold">Type</th>
    <th class="text-left px-3 py-2 font-bold">Notes</th>
  </tr>`;

  const sample = parsedRows.slice(0, 5);
  previewBody.innerHTML = sample.map(row => `
    <tr class="border-t border-white/5">
      <td class="px-3 py-2">${escapeHtml(row[0] || '')}</td>
      <td class="px-3 py-2">${typeLabel}</td>
      <td class="px-3 py-2 text-bone/60">${escapeHtml(row[1] || '') || '—'}</td>
    </tr>
  `).join('');

  rowCountLabel.textContent = parsedRows.length + ' row(s) total will be imported.';
}

// ===== Step 3: import with progress =====
startImportBtn.addEventListener('click', async () => {
  const singleType = document.querySelector('input[name="singleType"]:checked')?.value || 'movie';

  const items = parsedRows
    .map(row => ({
      title: (row[0] || '').toString().trim(),
      status: (row[1] || '').toString().trim(),
      type: singleType
    }))
    .filter(item => item.title !== '');

  if (!items.length) {
    alert('No valid rows with a title were found.');
    return;
  }

  mapSection.classList.add('hidden');
  progressSection.classList.remove('hidden');
  progressSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

  let added = 0, skipped = 0, failed = 0;

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    progressLabel.textContent = `Importing "${item.title}" (${i + 1} / ${items.length})...`;
    progressBarFill.style.width = Math.round((i / items.length) * 100) + '%';

    const logRow = document.createElement('div');
    logRow.className = 'px-3 py-2 flex items-center justify-between gap-2';

    let result;
    try {
      result = await importOneItem(item.title, item.status, item.type);
    } catch (err) {
      result = { success: false, message: 'Network error' };
    }

    if (result.success && result.skipped) {
      skipped++;
      logRow.innerHTML = `<span class="truncate">${escapeHtml(item.title)}</span><span class="text-amber flex-shrink-0">Skipped (duplicate)</span>`;
    } else if (result.success) {
      added++;
      logRow.innerHTML = `<span class="truncate">${escapeHtml(item.title)}</span><span class="text-green-400 flex-shrink-0">${result.found ? 'Added' : 'Added (no match found)'}</span>`;
    } else {
      failed++;
      logRow.innerHTML = `<span class="truncate">${escapeHtml(item.title)}</span><span class="text-rust flex-shrink-0">Failed</span>`;
    }

    importLog.appendChild(logRow);
    importLog.scrollTop = importLog.scrollHeight;
    countAdded.textContent = added;
    countSkipped.textContent = skipped;
    countFailed.textContent = failed;
  }

  progressBarFill.style.width = '100%';
  progressLabel.textContent = `Done — processed ${items.length} row(s).`;
  doneBtn.classList.remove('hidden');
});

async function importOneItem(title, status, type) {
  const res = await fetch('api/import.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, status, type })
  });
  return res.json();
}
</script>

</body>
</html>
