<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pdo = getDB();

// Type filter
$filter = $_GET['filter'] ?? 'movie';
$search = trim($_GET['q'] ?? '');

$sql = "SELECT * FROM media_items WHERE 1=1";
$params = [];

if ($filter === 'movie' || $filter === 'game') {
    $sql .= " AND type = :type";
    $params['type'] = $filter;
}

if ($search !== '') {
    $sql .= " AND title LIKE :search";
    $params['search'] = "%$search%";
}

$sql .= " ORDER BY title ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

$totalMovies = $pdo->query("SELECT COUNT(*) FROM media_items WHERE type='movie'")->fetchColumn();
$totalGames = $pdo->query("SELECT COUNT(*) FROM media_items WHERE type='game'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr" class="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Archive | Movies &amp; Games</title>
<script>
  // Prevent color flash on page load
  (function() {
    var t = localStorage.getItem('mt-theme') || 'dark';
    if (t === 'light') document.documentElement.classList.remove('dark');
    else document.documentElement.classList.add('dark');
  })();
</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<script>
  tailwind.config = {
    darkMode: 'class',
    theme: {
      extend: {
        fontFamily: {
          vazir: ['Vazirmatn', 'sans-serif'],
          mono: ['Space Mono', 'monospace'],
        },
        colors: {
          ink: '#0f0e0c',
          panel: '#1a1815',
          amber: '#e0a458',
          rust: '#c1502e',
          bone: '#e8e2d4',
        }
      }
    }
  }
</script>
<style>
  @font-face {
    font-family: 'Mikhak';
    src: url('assets/fonts/Mikhak-SemiBold.ttf') format('truetype');
    font-weight: 600;
    font-style: normal;
    font-display: swap;
  }
  body { font-family: 'Mikhak', 'Vazirmatn', sans-serif; }
  .mono { font-family: 'Space Mono', monospace; direction: ltr; }
  .grain::before {
    content: "";
    position: fixed; inset: 0;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");
    pointer-events: none; z-index: 50;
  }
  .card-poster { aspect-ratio: 2/3; flex-shrink: 0; }

  /* Hide scrollbar visually while keeping the element scrollable */
  .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
  .scrollbar-hide::-webkit-scrollbar { display: none; width: 0; height: 0; }

  /* Light mode */
  html:not(.dark) body { background: #f5f2ea; color: #241f16; }
  html:not(.dark) header { background: rgba(245,242,234,0.9); border-color: rgba(36,31,22,0.1); }
  html:not(.dark) .bg-panel { background: #ffffff; border-color: rgba(36,31,22,0.1); }
  html:not(.dark) .item-card { border-color: rgba(0,0,0,0.4); }
  html:not(.dark) .bg-ink { background: #eee9dd; }
  html:not(.dark) .border-white\/10 { border-color: rgba(36,31,22,0.1); }
  html:not(.dark) .border-white\/15 { border-color: rgba(36,31,22,0.15); }
  html:not(.dark) .text-bone { color: #241f16; }
  html:not(.dark) .text-bone\/80 { color: rgba(36,31,22,0.8); }
  html:not(.dark) .text-bone\/60 { color: rgba(36,31,22,0.6); }
  html:not(.dark) .text-bone\/50 { color: rgba(36,31,22,0.55); }
  html:not(.dark) .text-bone\/40 { color: rgba(36,31,22,0.45); }
  html:not(.dark) .text-bone\/30 { color: rgba(36,31,22,0.35); }
  html:not(.dark) ::-webkit-scrollbar-track { background: #eee9dd; }
  html:not(.dark) input::placeholder { color: rgba(36,31,22,0.4); opacity: 1; }

  ::-webkit-scrollbar { width: 8px; }
  ::-webkit-scrollbar-track { background: #1a1815; }
  ::-webkit-scrollbar-thumb { background: #e0a458; border-radius: 4px; }

  /* Delete modal */
  .modal-overlay { transition: opacity 0.2s ease; }
  .modal-box { transition: transform 0.2s ease, opacity 0.2s ease; }
</style>
</head>
<body class="bg-ink text-bone min-h-screen grain transition-colors duration-300">

<!-- Header -->
<header class="border-b border-white/10 sticky top-0 bg-ink/90 backdrop-blur-md z-40">
  <div class="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
    <div>
      <h1 class="text-2xl font-extrabold tracking-tight">My<span class="text-amber">Archive</span></h1>
      <p class="mono text-[11px] text-bone/40 tracking-widest">MOVIES &amp; GAMES LOG</p>
    </div>
    <div class="flex items-center gap-6 mono text-sm">
      <div class="text-center">
        <div class="text-amber text-xl font-bold"><?= $totalMovies ?></div>
        <div class="text-bone/40 text-[10px] tracking-wider">FILMS</div>
      </div>
      <div class="text-center">
        <div class="text-rust text-xl font-bold"><?= $totalGames ?></div>
        <div class="text-bone/40 text-[10px] tracking-wider">GAMES</div>
      </div>
      <a href="import.php" title="Bulk import"
        class="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center text-lg hover:border-amber transition-colors">
        📥
      </a>
      <a href="backup.php" title="Database &amp; backups"
        class="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center text-lg hover:border-amber transition-colors">
        💾
      </a>
      <button id="themeToggle" title="Toggle theme"
        class="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center text-lg hover:border-amber transition-colors">
        <span id="themeIcon">🌙</span>
      </button>
    </div>
  </div>
</header>

<?php
// Warn if the archive is empty but a backup still has data (e.g. DB was wiped).
$lostBanner = null;
if ($totalMovies + $totalGames === 0) {
    foreach (dbBackupFiles() as $bf) {
        $bi = dbBackupInfo($bf);
        if ($bi && $bi['items'] > 0) { $lostBanner = $bi; break; }
    }
}
?>
<div class="max-w-6xl mx-auto px-6 py-10">
  <?php if ($lostBanner): ?>
  <div class="mb-6 rounded-xl border border-amber/50 bg-amber/10 px-4 py-3 text-sm flex flex-wrap items-center gap-3">
    <span>The archive is empty, but a backup from <b><?= htmlspecialchars($lostBanner['time']) ?></b> has <b><?= $lostBanner['items'] ?></b> items.</span>
    <a href="backup.php" class="ms-auto font-bold text-amber underline">Restore from backup</a>
  </div>
  <?php endif; ?>

  <!-- Add form -->
  <section class="bg-panel border border-white/10 rounded-2xl p-6 mb-10 relative">
    <div class="absolute -top-10 -left-10 w-40 h-40 bg-amber/10 rounded-full blur-3xl pointer-events-none"></div>
    <h2 class="text-lg font-bold mb-1 flex items-center gap-2">
      <span class="w-6 h-6 rounded-full bg-amber/20 text-amber flex items-center justify-center text-sm">+</span>
      Add New Item
    </h2>
    <p class="text-bone/50 text-sm mb-5">Start typing — we'll search movies and games (TMDb & RAWG) at once. Pick a result, add your own notes if you like.</p>

    <form id="addForm" class="grid grid-cols-1 md:grid-cols-[1.4fr_1fr_auto] gap-3 items-stretch">
      <div class="relative">
        <input type="text" name="title" id="titleInput" required autocomplete="off" placeholder="Search a movie or game title..."
          class="w-full bg-ink border border-white/15 rounded-xl px-4 py-3 text-bone placeholder:text-bone/30 focus:outline-none focus:border-amber transition-colors">

        <div id="searchDropdown" class="hidden absolute top-full mt-2 w-full bg-panel border border-white/15 rounded-xl shadow-2xl overflow-hidden z-50 max-h-80 overflow-y-auto"></div>
      </div>

      <input type="text" name="status" id="statusInput" autocomplete="off" placeholder="Your notes (e.g. Finished, 8/10, Replaying...)"
        class="bg-ink border border-white/15 rounded-xl px-4 py-3 text-bone placeholder:text-bone/30 focus:outline-none focus:border-amber transition-colors">

      <button type="submit" id="submitBtn"
        class="bg-amber text-ink font-bold rounded-xl px-6 py-3 hover:bg-amber/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap">
        Add
      </button>
    </form>
    <div id="formStatus" class="mt-3 text-sm hidden"></div>
  </section>

  <!-- Filters -->
  <section class="flex flex-wrap items-center gap-3 mb-8">
    <div id="filterToggle" class="inline-flex items-center bg-panel border border-white/15 rounded-full p-1 gap-1">
      <button type="button" data-filter="movie"
         class="filter-btn px-4 py-1.5 rounded-full text-sm transition-colors <?= $filter==='movie' ? 'bg-amber text-ink font-bold' : 'text-bone/60 hover:text-bone' ?>">🎬 Movies</button>
      <button type="button" data-filter="game"
         class="filter-btn px-4 py-1.5 rounded-full text-sm transition-colors <?= $filter==='game' ? 'bg-amber text-ink font-bold' : 'text-bone/60 hover:text-bone' ?>">🎮 Games</button>
    </div>

    <div class="flex items-center">
      <input type="text" id="archiveSearchInput" value="<?= htmlspecialchars($search) ?>" placeholder="Search archive..." autocomplete="off"
        class="bg-panel border border-white/15 rounded-full px-4 py-2 text-sm w-56 focus:outline-none focus:border-amber">
    </div>

    <div id="deleteAllWrap" class="ms-auto flex items-center gap-2 <?= ($totalMovies > 0 || $totalGames > 0) ? '' : 'hidden' ?>">
      <button id="deleteAllMoviesBtn" type="button" data-type="movie"
        class="px-4 py-2 rounded-full text-sm border border-rust/40 text-rust hover:bg-rust/10 transition-colors <?= $totalMovies > 0 ? '' : 'hidden' ?>">
        🗑️ Delete All Movies
      </button>
      <button id="deleteAllGamesBtn" type="button" data-type="game"
        class="px-4 py-2 rounded-full text-sm border border-rust/40 text-rust hover:bg-rust/10 transition-colors <?= $totalGames > 0 ? '' : 'hidden' ?>">
        🗑️ Delete All Games
      </button>
    </div>
  </section>

  <!-- Grid (contents replaced live by JS as the archive search/filter changes) -->
  <div id="itemsContainer">
    <?php if (empty($items)): ?>
      <div class="text-center py-24 text-bone/30">
        <div class="text-5xl mb-4">🗂️</div>
        <p class="mono text-sm tracking-wide">Nothing added yet</p>
      </div>
    <?php else: ?>
    <section id="itemsGrid" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5 items-start">
      <?php foreach ($items as $item): ?>
        <?php include __DIR__ . '/includes/card.php'; ?>
      <?php endforeach; ?>
    </section>
    <?php endif; ?>
  </div>

</div>

<!-- Delete confirmation modal -->
<div id="deleteModal" class="fixed inset-0 z-[60] hidden items-center justify-center px-4">
  <div id="modalOverlay" class="modal-overlay absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
  <div id="modalBox" class="modal-box relative bg-panel border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl scale-95 opacity-0">
    <div class="w-12 h-12 rounded-full bg-rust/20 text-rust flex items-center justify-center text-2xl mx-auto mb-4">🗑️</div>
    <h3 class="text-lg font-bold text-center mb-2">Delete this item?</h3>
    <p id="modalItemName" class="text-bone/60 text-sm text-center mb-6">This item will be removed from your archive.</p>
    <div class="flex gap-3">
      <button id="modalCancelBtn" class="flex-1 py-3 rounded-xl border border-white/15 text-bone/70 hover:border-white/30 transition-colors font-bold text-sm">
        Cancel
      </button>
      <button id="modalConfirmBtn" class="flex-1 py-3 rounded-xl bg-rust text-white hover:bg-rust/90 transition-colors font-bold text-sm">
        Yes, delete
      </button>
    </div>
  </div>
</div>

<!-- Delete-all confirmation modal (stronger confirmation: type to confirm) -->
<div id="deleteAllModal" class="fixed inset-0 z-[60] hidden items-center justify-center px-4">
  <div id="deleteAllOverlay" class="modal-overlay absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
  <div id="deleteAllBox" class="modal-box relative bg-panel border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl scale-95 opacity-0">
    <div class="w-12 h-12 rounded-full bg-rust/20 text-rust flex items-center justify-center text-2xl mx-auto mb-4">⚠️</div>
    <h3 id="deleteAllTitle" class="text-lg font-bold text-center mb-2">Delete all movies?</h3>
    <p class="text-bone/60 text-sm text-center mb-4">This permanently removes <span id="deleteAllCount" class="font-bold text-bone">all</span>. This can't be undone.</p>
    <p class="text-bone/50 text-xs text-center mb-2">Type <span class="mono font-bold text-rust">DELETE</span> to confirm</p>
    <input type="text" id="deleteAllInput" autocomplete="off" placeholder="DELETE"
      class="w-full bg-ink border border-white/15 rounded-xl px-4 py-2.5 text-sm text-center mono placeholder:text-bone/20 focus:outline-none focus:border-rust mb-5">
    <div class="flex gap-3">
      <button id="deleteAllCancelBtn" class="flex-1 py-3 rounded-xl border border-white/15 text-bone/70 hover:border-white/30 transition-colors font-bold text-sm">
        Cancel
      </button>
      <button id="deleteAllConfirmBtn" disabled class="flex-1 py-3 rounded-xl bg-rust text-white hover:bg-rust/90 transition-colors font-bold text-sm disabled:opacity-40 disabled:cursor-not-allowed">
        Delete Everything
      </button>
    </div>
  </div>
</div>

<script>
// ===== Light/dark theme =====
const html = document.documentElement;
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');

function applyTheme(theme) {
  if (theme === 'light') {
    html.classList.remove('dark');
    themeIcon.textContent = '☀️';
  } else {
    html.classList.add('dark');
    themeIcon.textContent = '🌙';
  }
}

const savedTheme = localStorage.getItem('mt-theme') || 'dark';
applyTheme(savedTheme);

themeToggle.addEventListener('click', () => {
  const isDark = html.classList.contains('dark');
  const next = isDark ? 'light' : 'dark';
  applyTheme(next);
  localStorage.setItem('mt-theme', next);
});

// ===== Delete modal =====
const deleteModal = document.getElementById('deleteModal');
const modalOverlay = document.getElementById('modalOverlay');
const modalBox = document.getElementById('modalBox');
const modalItemName = document.getElementById('modalItemName');
const modalCancelBtn = document.getElementById('modalCancelBtn');
const modalConfirmBtn = document.getElementById('modalConfirmBtn');

let pendingDelete = null; // { id, cardEl }

function openDeleteModal(id, cardEl, title) {
  pendingDelete = { id, cardEl };
  modalItemName.textContent = title ? `"${title}" will be removed from your archive.` : 'This item will be removed from your archive.';
  deleteModal.classList.remove('hidden');
  deleteModal.classList.add('flex');
  requestAnimationFrame(() => {
    modalBox.classList.remove('scale-95', 'opacity-0');
    modalBox.classList.add('scale-100', 'opacity-100');
  });
}

function closeDeleteModal() {
  modalBox.classList.remove('scale-100', 'opacity-100');
  modalBox.classList.add('scale-95', 'opacity-0');
  setTimeout(() => {
    deleteModal.classList.add('hidden');
    deleteModal.classList.remove('flex');
    pendingDelete = null;
  }, 200);
}

modalCancelBtn.addEventListener('click', closeDeleteModal);
modalOverlay.addEventListener('click', closeDeleteModal);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !deleteModal.classList.contains('hidden')) closeDeleteModal();
});

modalConfirmBtn.addEventListener('click', async () => {
  if (!pendingDelete) return;
  const { id, cardEl } = pendingDelete;
  modalConfirmBtn.disabled = true;
  modalConfirmBtn.textContent = 'Deleting...';

  try {
    const res = await fetch('api/delete.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    const data = await res.json();
    if (data.success) {
      cardEl.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
      cardEl.style.opacity = '0';
      cardEl.style.transform = 'scale(0.9)';
      setTimeout(() => cardEl.remove(), 250);
    }
  } catch (err) {
    // Delete failed - fail silently, user can retry
  } finally {
    modalConfirmBtn.disabled = false;
    modalConfirmBtn.textContent = 'Yes, delete';
    closeDeleteModal();
  }
});

// ===== Delete-all modal (per type: movies or games) =====
const deleteAllModal = document.getElementById('deleteAllModal');
const deleteAllOverlay = document.getElementById('deleteAllOverlay');
const deleteAllBox = document.getElementById('deleteAllBox');
const deleteAllTitle = document.getElementById('deleteAllTitle');
const deleteAllCount = document.getElementById('deleteAllCount');
const deleteAllInput = document.getElementById('deleteAllInput');
const deleteAllCancelBtn = document.getElementById('deleteAllCancelBtn');
const deleteAllConfirmBtn = document.getElementById('deleteAllConfirmBtn');
let deleteAllType = null;

function openDeleteAllModal(type) {
  deleteAllType = type;
  const label = type === 'movie' ? 'movies' : 'games';
  // Read live counts from the header badges (kept in sync by refreshArchive), not the initial PHP render.
  const totalCount = parseInt((type === 'movie' ? headerMoviesCount : headerGamesCount)?.textContent || '0', 10);
  deleteAllTitle.textContent = `Delete all ${label}?`;
  deleteAllCount.textContent = (totalCount + (totalCount === 1 ? ' item' : ' items')) + ` (${label})`;
  deleteAllInput.value = '';
  deleteAllConfirmBtn.disabled = true;

  deleteAllModal.classList.remove('hidden');
  deleteAllModal.classList.add('flex');
  requestAnimationFrame(() => {
    deleteAllBox.classList.remove('scale-95', 'opacity-0');
    deleteAllBox.classList.add('scale-100', 'opacity-100');
  });
  setTimeout(() => deleteAllInput.focus(), 210);
}

const deleteAllMoviesBtn = document.getElementById('deleteAllMoviesBtn');
const deleteAllGamesBtn = document.getElementById('deleteAllGamesBtn');
if (deleteAllMoviesBtn) deleteAllMoviesBtn.addEventListener('click', () => openDeleteAllModal('movie'));
if (deleteAllGamesBtn) deleteAllGamesBtn.addEventListener('click', () => openDeleteAllModal('game'));

function closeDeleteAllModal() {
  deleteAllBox.classList.remove('scale-100', 'opacity-100');
  deleteAllBox.classList.add('scale-95', 'opacity-0');
  setTimeout(() => {
    deleteAllModal.classList.add('hidden');
    deleteAllModal.classList.remove('flex');
  }, 200);
}

deleteAllCancelBtn.addEventListener('click', closeDeleteAllModal);
deleteAllOverlay.addEventListener('click', closeDeleteAllModal);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !deleteAllModal.classList.contains('hidden')) closeDeleteAllModal();
});

deleteAllInput.addEventListener('input', () => {
  deleteAllConfirmBtn.disabled = deleteAllInput.value.trim() !== 'DELETE';
});

deleteAllConfirmBtn.addEventListener('click', async () => {
  if (deleteAllInput.value.trim() !== 'DELETE' || !deleteAllType) return;

  deleteAllConfirmBtn.disabled = true;
  deleteAllConfirmBtn.textContent = 'Deleting...';

  try {
    const res = await fetch('api/delete-all.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'type=' + encodeURIComponent(deleteAllType)
    });
    const data = await res.json();
    if (data.success) {
      location.reload();
    } else {
      deleteAllConfirmBtn.textContent = 'Delete Everything';
      deleteAllConfirmBtn.disabled = false;
      alert('Something went wrong: ' + (data.message || 'unknown error'));
    }
  } catch (err) {
    deleteAllConfirmBtn.textContent = 'Delete Everything';
    deleteAllConfirmBtn.disabled = false;
    alert('Could not reach the server.');
  }
});

// ===== Live archive filter/search (movies vs games, plus text search) =====
const itemsContainer = document.getElementById('itemsContainer');
const archiveSearchInput = document.getElementById('archiveSearchInput');
const filterBtns = document.querySelectorAll('.filter-btn');
const deleteAllMoviesBtnRef = () => document.getElementById('deleteAllMoviesBtn');
const deleteAllGamesBtnRef = () => document.getElementById('deleteAllGamesBtn');
const deleteAllWrap = document.getElementById('deleteAllWrap');
const headerMoviesCount = document.querySelector('header .text-amber.text-xl');
const headerGamesCount = document.querySelector('header .text-rust.text-xl');

let currentFilter = '<?= $filter === 'game' ? 'game' : 'movie' ?>';
let archiveSearchTimer = null;
let archiveAbort = null;

function setActiveFilterBtn() {
  filterBtns.forEach(btn => {
    const active = btn.dataset.filter === currentFilter;
    btn.classList.toggle('bg-amber', active);
    btn.classList.toggle('text-ink', active);
    btn.classList.toggle('font-bold', active);
    btn.classList.toggle('text-bone/60', !active);
  });
}

async function refreshArchive() {
  if (archiveAbort) archiveAbort.abort();
  archiveAbort = new AbortController();

  const q = archiveSearchInput.value.trim();
  const params = new URLSearchParams({ filter: currentFilter, q });

  try {
    const res = await fetch(`api/filter.php?${params.toString()}`, { signal: archiveAbort.signal });
    const data = await res.json();
    if (!data.success) return;

    if (data.count > 0) {
      itemsContainer.innerHTML = data.html;
    } else {
      itemsContainer.innerHTML = `
        <div class="text-center py-24 text-bone/30">
          <div class="text-5xl mb-4">🗂️</div>
          <p class="mono text-sm tracking-wide">Nothing found</p>
        </div>`;
    }

    if (headerMoviesCount) headerMoviesCount.textContent = data.totalMovies;
    if (headerGamesCount) headerGamesCount.textContent = data.totalGames;

    const moviesBtn = deleteAllMoviesBtnRef();
    const gamesBtn = deleteAllGamesBtnRef();
    if (moviesBtn) moviesBtn.classList.toggle('hidden', data.totalMovies <= 0);
    if (gamesBtn) gamesBtn.classList.toggle('hidden', data.totalGames <= 0);
    if (deleteAllWrap) deleteAllWrap.classList.toggle('hidden', data.totalMovies <= 0 && data.totalGames <= 0);

    updateAllNoteOverflowIndicators();
  } catch (err) {
    if (err.name !== 'AbortError') {
      // Fail silently and leave the previous results showing; user can retry by typing again.
    }
  }
}

filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    if (btn.dataset.filter === currentFilter) return;
    currentFilter = btn.dataset.filter;
    setActiveFilterBtn();
    refreshArchive();
  });
});

archiveSearchInput.addEventListener('input', () => {
  clearTimeout(archiveSearchTimer);
  archiveSearchTimer = setTimeout(refreshArchive, 300);
});

const form = document.getElementById('addForm');
const submitBtn = document.getElementById('submitBtn');
const formStatus = document.getElementById('formStatus');
const titleInput = document.getElementById('titleInput');
const statusInput = document.getElementById('statusInput');
const searchDropdown = document.getElementById('searchDropdown');

let searchTimer = null;
let currentAbort = null;
let pickedItem = null; // Item the user selected from the dropdown (movie or game, with its type)

function closeDropdown() {
  searchDropdown.classList.add('hidden');
  searchDropdown.innerHTML = '';
}

function renderDropdown(results) {
  if (!results.length) {
    searchDropdown.innerHTML = `<div class="p-4 text-center text-bone/40 text-sm">No results found</div>`;
    searchDropdown.classList.remove('hidden');
    return;
  }

  searchDropdown.innerHTML = results.map((r, i) => {
    const year = r.release_date ? r.release_date.slice(0, 4) : '';
    const typeIcon = r.type === 'movie' ? '🎬' : '🎮';
    // Label each result with its source so it's clear which site it'll link to.
    const sourceLabel = r.source === 'rawg' ? 'RAWG'
      : (r.type === 'movie' ? 'Movie' : 'Game');
    const img = r.poster_url
      ? `<img src="${r.thumb_url || r.poster_url}" onerror="this.onerror=null;this.src=this.dataset.full" data-full="${r.poster_url}" width="40" height="56" decoding="async" class="w-10 h-14 object-cover rounded-md flex-shrink-0" loading="lazy">`
      : `<div class="w-10 h-14 rounded-md bg-ink flex items-center justify-center text-lg flex-shrink-0">${typeIcon}</div>`;
    return `
      <button type="button" data-idx="${i}" class="dropdown-item w-full flex items-center gap-3 p-3 hover:bg-amber/10 transition-colors text-left border-b border-white/5 last:border-0">
        ${img}
        <div class="min-w-0 flex-1">
          <div class="text-sm font-bold truncate">${escapeHtml(r.title)}</div>
          <div class="mono text-[10px] text-bone/40">${typeIcon} ${sourceLabel}${year ? ' · ' + year : ''}</div>
        </div>
      </button>
    `;
  }).join('');

  searchDropdown.classList.remove('hidden');

  searchDropdown.querySelectorAll('.dropdown-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.idx, 10);
      const chosen = results[idx];
      pickedItem = chosen;
      titleInput.value = chosen.title;
      closeDropdown();
      statusInput.focus();
    });
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

titleInput.addEventListener('input', () => {
  pickedItem = null; // Manual typing clears the previous selection
  const q = titleInput.value.trim();
  clearTimeout(searchTimer);

  if (q.length < 2) {
    closeDropdown();
    return;
  }

  searchTimer = setTimeout(async () => {
    if (currentAbort) currentAbort.abort();
    currentAbort = new AbortController();

    searchDropdown.innerHTML = `<div class="p-4 text-center text-bone/40 text-sm">Searching...</div>`;
    searchDropdown.classList.remove('hidden');

    try {
      const res = await fetch(`api/search.php?q=${encodeURIComponent(q)}`, {
        signal: currentAbort.signal
      });
      const data = await res.json();
      // The user may have changed the text meanwhile; only render if it still matches
      if (titleInput.value.trim() === q) {
        renderDropdown(data.results || []);
      }
    } catch (err) {
      if (err.name !== 'AbortError') closeDropdown();
    }
  }, 400);
});

document.addEventListener('click', (e) => {
  if (!e.target.closest('#titleInput') && !e.target.closest('#searchDropdown')) {
    closeDropdown();
  }
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const title = titleInput.value.trim();
  const status = statusInput.value;

  if (!title) return;

  if (!pickedItem) {
    formStatus.classList.remove('hidden');
    formStatus.className = 'mt-3 text-sm text-rust';
    formStatus.textContent = '⚠️ Please pick a result from the dropdown first.';
    titleInput.focus();
    return;
  }

  closeDropdown();

  submitBtn.disabled = true;
  submitBtn.textContent = 'Adding...';
  formStatus.classList.remove('hidden');
  formStatus.className = 'mt-3 text-sm text-amber';
  formStatus.textContent = '⏳ Adding...';

  try {
    const res = await fetch('api/add.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, status, picked: pickedItem })
    });
    const data = await res.json();

    if (data.success) {
      formStatus.className = 'mt-3 text-sm text-green-400';
      formStatus.textContent = '✅ "' + data.item.title + '" added.';
      setTimeout(() => location.reload(), 700);
    } else {
      formStatus.className = 'mt-3 text-sm text-rust';
      formStatus.textContent = '⚠️ ' + (data.message || 'Something went wrong.');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Add';
    }
  } catch (err) {
    formStatus.className = 'mt-3 text-sm text-rust';
    formStatus.textContent = '⚠️ Could not reach the server.';
    submitBtn.disabled = false;
    submitBtn.textContent = 'Add';
  }
});

function deleteItem(id, btn, title) {
  const cardEl = btn.closest('.item-card-wrapper');
  openDeleteModal(id, cardEl, title);
}

// ===== Inline note editing =====
document.addEventListener('keydown', (e) => {
  if (!e.target.classList.contains('note-textarea')) return;
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    e.preventDefault();
    const block = e.target.closest('[data-note-block]');
    saveNote(block.querySelector('.note-save-btn'));
  } else if (e.key === 'Escape') {
    e.preventDefault();
    const block = e.target.closest('[data-note-block]');
    cancelEditNote(block.querySelector('.note-cancel-btn'));
  }
});

// Shows the small "⌄" indicator only on notes that are genuinely more than one line tall (i.e. scrollable).
// Compares against the element's own line-height (with slack for font-metric rounding) rather than a raw
// pixel diff, since fonts can report a hair more than the set line-height even for a single line.
function updateNoteOverflowIndicator(displayEl) {
  const indicator = displayEl.parentElement.querySelector('.note-more-indicator');
  if (!indicator) return;
  const lineHeight = parseFloat(getComputedStyle(displayEl).lineHeight) || 16;
  const hasMore = displayEl.scrollHeight > lineHeight * 1.5;
  indicator.classList.toggle('hidden', !hasMore);
}

function updateAllNoteOverflowIndicators() {
  document.querySelectorAll('.note-display').forEach(updateNoteOverflowIndicator);
}

document.addEventListener('DOMContentLoaded', updateAllNoteOverflowIndicators);
window.addEventListener('resize', updateAllNoteOverflowIndicators);
if (document.fonts && document.fonts.ready) {
  // Custom font can change wrapping once it finishes loading, so re-check after it's ready
  document.fonts.ready.then(updateAllNoteOverflowIndicators);
}

function startEditNote(displayEl) {
  const block = displayEl.closest('[data-note-block]');
  const editEl = block.querySelector('.note-edit');
  const textarea = block.querySelector('.note-textarea');
  const indicator = block.querySelector('.note-more-indicator');

  displayEl.classList.add('hidden');
  if (indicator) indicator.classList.add('hidden');
  editEl.classList.remove('hidden');
  textarea.focus();
  // put cursor at the end
  const len = textarea.value.length;
  textarea.setSelectionRange(len, len);
}

function cancelEditNote(btn) {
  const block = btn.closest('[data-note-block]');
  const displayEl = block.querySelector('.note-display');
  const editEl = block.querySelector('.note-edit');
  const textarea = block.querySelector('.note-textarea');

  // Reset textarea back to whatever is currently displayed
  const currentText = displayEl.dataset.rawValue ?? displayEl.textContent.trim();
  textarea.value = currentText === '+ Add note' ? '' : currentText;

  editEl.classList.add('hidden');
  displayEl.classList.remove('hidden');
  updateNoteOverflowIndicator(displayEl);
}

// ===== Inline title editing =====
document.addEventListener('keydown', (e) => {
  if (!e.target.classList.contains('title-textarea')) return;
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    e.preventDefault();
    const block = e.target.closest('[data-title-block]');
    saveTitle(block.querySelector('.title-save-btn'));
  } else if (e.key === 'Escape') {
    e.preventDefault();
    const block = e.target.closest('[data-title-block]');
    cancelEditTitle(block.querySelector('.title-cancel-btn'));
  }
});

function startEditTitle(displayEl) {
  const block = displayEl.closest('[data-title-block]');
  const editEl = block.querySelector('.title-edit');
  const textarea = block.querySelector('.title-textarea');

  displayEl.closest('div').classList.add('hidden');
  editEl.classList.remove('hidden');
  textarea.focus();
  const len = textarea.value.length;
  textarea.setSelectionRange(len, len);
}

function cancelEditTitle(btn) {
  const block = btn.closest('[data-title-block]');
  const displayWrap = block.querySelector('.title-display').closest('div');
  const displayEl = block.querySelector('.title-display');
  const editEl = block.querySelector('.title-edit');
  const textarea = block.querySelector('.title-textarea');

  textarea.value = displayEl.dataset.rawValue ?? displayEl.textContent.trim();

  editEl.classList.add('hidden');
  displayWrap.classList.remove('hidden');
}

async function saveTitle(btn) {
  const block = btn.closest('[data-title-block]');
  const id = block.dataset.itemId;
  const displayEl = block.querySelector('.title-display');
  const displayWrap = displayEl.closest('div');
  const editEl = block.querySelector('.title-edit');
  const textarea = block.querySelector('.title-textarea');
  const saveBtn = block.querySelector('.title-save-btn');
  const cancelBtn = block.querySelector('.title-cancel-btn');

  const newValue = textarea.value.trim();

  if (newValue === '') {
    alert('Title cannot be empty.');
    return;
  }

  saveBtn.disabled = true;
  cancelBtn.disabled = true;
  saveBtn.textContent = 'Saving...';

  try {
    const res = await fetch('api/update-title.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, title: newValue })
    });
    const data = await res.json();

    if (data.success) {
      displayEl.textContent = newValue;
      displayEl.dataset.rawValue = newValue;
      editEl.classList.add('hidden');
      displayWrap.classList.remove('hidden');
    } else {
      alert('Could not save the title: ' + (data.message || 'unknown error'));
    }
  } catch (err) {
    alert('Could not reach the server.');
  } finally {
    saveBtn.disabled = false;
    cancelBtn.disabled = false;
    saveBtn.textContent = 'Save';
  }
}

async function saveNote(btn) {
  const block = btn.closest('[data-note-block]');
  const id = block.dataset.itemId;
  const displayEl = block.querySelector('.note-display');
  const editEl = block.querySelector('.note-edit');
  const textarea = block.querySelector('.note-textarea');
  const saveBtn = block.querySelector('.note-save-btn');
  const cancelBtn = block.querySelector('.note-cancel-btn');

  const newValue = textarea.value.trim();

  saveBtn.disabled = true;
  cancelBtn.disabled = true;
  saveBtn.textContent = 'Saving...';

  try {
    const res = await fetch('api/update-note.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, status: newValue })
    });
    const data = await res.json();

    if (data.success) {
      if (newValue === '') {
        displayEl.textContent = '+ Add note';
        displayEl.classList.add('italic', 'text-bone/30');
        displayEl.dataset.rawValue = '';
      } else {
        displayEl.textContent = newValue;
        displayEl.classList.remove('italic', 'text-bone/30');
        displayEl.dataset.rawValue = newValue;
      }
      editEl.classList.add('hidden');
      displayEl.classList.remove('hidden');
      updateNoteOverflowIndicator(displayEl);
    } else {
      alert('Could not save the note: ' + (data.message || 'unknown error'));
    }
  } catch (err) {
    alert('Could not reach the server.');
  } finally {
    saveBtn.disabled = false;
    cancelBtn.disabled = false;
    saveBtn.textContent = 'Save';
  }
}
</script>

</body>
</html>