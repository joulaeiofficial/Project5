<?php
// Backup manager: create / download / restore backups, export JSON, import from old MySQL.
require_once __DIR__ . '/config/config.php';

// Local use only (this app has no login).
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($ip, ['127.0.0.1', '::1'], true)) { http_response_code(403); exit('Local access only.'); }

session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

$pdo = getDB();
$msg = '';
$err = '';

// ---- downloads (GET) ----
if (isset($_GET['download'])) {
    $name = $_GET['download'];
    $path = $name === 'current' ? null : BACKUP_DIR . '/' . basename($name);
    if ($name === 'current') {
        $path = BACKUP_DIR . '/.download-tmp.sqlite';
        @unlink($path);
        $pdo->exec('VACUUM INTO ' . $pdo->quote($path));
        $dl = 'media-' . date('Ymd-His') . '.sqlite';
    } else {
        if (!dbBackupInfo($path) || !is_file($path)) { http_response_code(404); exit('Not found'); }
        $dl = basename($path);
    }
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $dl . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    if ($name === 'current') @unlink($path);
    exit;
}
if (isset($_GET['export'])) {
    $rows = $pdo->query('SELECT * FROM media_items ORDER BY id')->fetchAll();
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="media-export-' . date('Ymd-His') . '.json"');
    echo json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

// ---- actions (POST) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, $_POST['csrf'] ?? '')) {
        $err = 'Invalid session, reload the page.';
    } else {
        try {
            $action = $_POST['action'] ?? '';
            if ($action === 'create') {
                $p = createBackup('manual');
                $msg = $p ? 'Backup created: ' . basename($p) : 'Backup failed.';
            } elseif ($action === 'restore') {
                restoreBackup($_POST['file'] ?? '');
                $msg = 'Restored from ' . htmlspecialchars($_POST['file']) . '. (Your previous data was saved as a "before-restore" backup.)';
                $pdo = getDB();
            } elseif ($action === 'import_mysql') {
                createBackup('before-mysql-import', false);
                $n = dbImportFromMySQL($pdo);
                $msg = $n > 0 ? "$n items imported from the old MySQL database." : 'Nothing to import (MySQL is off, has no database, or all items already exist).';
            }
        } catch (Throwable $e) {
            $err = $e->getMessage();
        }
    }
}

$total = (int)$pdo->query('SELECT COUNT(*) FROM media_items')->fetchColumn();
$backups = array_values(array_filter(array_map('dbBackupInfo', dbBackupFiles())));
$recovered = is_file(DATA_DIR . '/RECOVERED.txt') ? trim(file_get_contents(DATA_DIR . '/RECOVERED.txt')) : '';
function fmtSize($b) { return $b >= 1048576 ? round($b / 1048576, 1) . ' MB' : max(1, round($b / 1024)) . ' KB'; }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr" class="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Backups | My Archive</title>
<script>
  (function() {
    var t = localStorage.getItem('mt-theme') || 'dark';
    if (t === 'light') document.documentElement.classList.remove('dark');
    else document.documentElement.classList.add('dark');
  })();
</script>
<script src="https://cdn.tailwindcss.com"></script>
<script>
  tailwind.config = { darkMode: 'class', theme: { extend: { colors: { ink: '#0f0e0c', panel: '#1a1815', amber: '#e0a458', rust: '#c1502e', bone: '#e8e2d4' } } } }
</script>
<style>
  @font-face { font-family: 'Mikhak'; src: url('assets/fonts/Mikhak-SemiBold.ttf') format('truetype'); font-weight: 600; font-display: swap; }
  body { font-family: 'Mikhak', 'Vazirmatn', sans-serif; }
  html:not(.dark) body { background: #f6f2ea; color: #1b1915; }
  html:not(.dark) .card { background: #fff; border-color: rgba(0,0,0,.1); }
  .card { background: #1a1815; border: 1px solid rgba(255,255,255,.1); border-radius: 1rem; }
  .btn { border: 1px solid rgba(232,226,212,.2); border-radius: .75rem; padding: .5rem 1rem; font-weight: 700; font-size: .85rem; }
  .btn:hover { border-color: #e0a458; }
</style>
</head>
<body class="bg-ink text-bone min-h-screen">
<div class="max-w-3xl mx-auto px-6 py-10">
  <a href="index.php" class="text-sm text-bone/50 hover:text-amber">&larr; Back to archive</a>
  <h1 class="text-2xl font-extrabold mt-3 mb-1">Database &amp; Backups</h1>
  <p class="text-bone/50 text-sm mb-6">
    Database file: <code class="text-amber">data/media.sqlite</code> &middot; <?= $total ?> items.
    A verified backup is made automatically once a day and before any bulk delete or restore.
  </p>

  <?php if ($msg): ?><div class="card p-4 mb-4 text-sm" style="border-color:#4ade80"><?= $msg ?></div><?php endif; ?>
  <?php if ($err): ?><div class="card p-4 mb-4 text-sm" style="border-color:#c1502e"><?= htmlspecialchars($err) ?></div><?php endif; ?>
  <?php if ($recovered): ?><div class="card p-4 mb-4 text-sm" style="border-color:#e0a458">Auto-recovery happened earlier:<br><code class="text-xs"><?= htmlspecialchars($recovered) ?></code></div><?php endif; ?>

  <div class="card p-5 mb-6 flex flex-wrap gap-3 items-center">
    <form method="post"><input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="action" value="create">
      <button class="btn">💾 Backup now</button></form>
    <a class="btn" href="?download=current">⬇ Download database</a>
    <a class="btn" href="?export=1">⬇ Export JSON</a>
    <form method="post" onsubmit="return confirm('Copy items from the old MySQL database (skips ones that already exist)?')">
      <input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="action" value="import_mysql">
      <button class="btn">↪ Import from old MySQL</button></form>
  </div>

  <h2 class="font-bold mb-3">Backups (<?= count($backups) ?>)</h2>
  <div class="card divide-y divide-white/10">
    <?php if (!$backups): ?><div class="p-5 text-sm text-bone/50">No backups yet. The first one is created automatically once there is data.</div><?php endif; ?>
    <?php foreach ($backups as $b): ?>
      <div class="p-4 flex flex-wrap items-center gap-3 text-sm">
        <div class="flex-1 min-w-[220px]">
          <div class="font-bold"><?= htmlspecialchars($b['time']) ?> <span class="text-bone/40 font-normal">· <?= htmlspecialchars($b['reason']) ?></span></div>
          <div class="text-bone/50 text-xs"><?= $b['items'] ?> items · <?= fmtSize($b['size']) ?></div>
        </div>
        <a class="btn" href="?download=<?= urlencode($b['name']) ?>">⬇</a>
        <form method="post" onsubmit="return confirm('Replace the current database with this backup? (Current data is backed up first.)')">
          <input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="action" value="restore">
          <input type="hidden" name="file" value="<?= htmlspecialchars($b['name']) ?>">
          <button class="btn" style="border-color:#c1502e">↩ Restore</button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>
</div>
</body>
</html>
