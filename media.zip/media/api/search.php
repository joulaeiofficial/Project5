<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/helpers.php';

$title = trim($_GET['q'] ?? '');

if ($title === '' || mb_strlen($title) < 2) {
    echo json_encode(['results' => []]);
    exit;
}

// If the user pasted a TMDb movie/tv URL, resolve that exact item directly
// instead of doing a text search.
$tmdbUrl = parseTMDbUrl($title);
if ($tmdbUrl !== null) {
    $direct = fetchTMDbById($tmdbUrl['media_type'], $tmdbUrl['id']);
    if ($direct !== null) {
        $direct['thumb_url'] = thumbUrl($direct['poster_url'] ?? null);
        echo json_encode(['results' => [$direct]]);
        exit;
    }
    // Recognized as a TMDb URL but the id didn't resolve - fall through to
    // a normal text search as a last resort (in case of a malformed link).
}

// Search both sources at once, tag each result with its type, and merge
$movies = searchMediaList($title, 'movie', 25);
$games = searchMediaList($title, 'game', 25);

foreach ($movies as &$m) { $m['type'] = 'movie'; }
unset($m);
foreach ($games as &$g) { $g['type'] = 'game'; }
unset($g);

$results = array_merge($movies, $games);

// Small thumbnails for the dropdown (40x56 on screen) - the full poster_url is still what gets saved.
foreach ($results as &$r) { $r['thumb_url'] = thumbUrl($r['poster_url'] ?? null); }
unset($r);

echo json_encode(['results' => $results]);
