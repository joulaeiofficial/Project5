<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';

$type = $_POST['type'] ?? '';
if ($type !== 'movie' && $type !== 'game') {
    echo json_encode(['success' => false, 'message' => 'Invalid or missing type']);
    exit;
}

try {
    $pdo = getDB();
    // Safety net: always snapshot before a bulk delete so it can be undone from backup.php
    if (createBackup('before-delete-all', false) === null && (int)$pdo->query('SELECT COUNT(*) FROM media_items')->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'Backup failed, nothing was deleted.']);
        exit;
    }
    $stmt = $pdo->prepare("DELETE FROM media_items WHERE type = :type");
    $stmt->execute(['type' => $type]);
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
