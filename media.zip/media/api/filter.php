<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/helpers.php';
$pdo = getDB();

// Same filtering logic as index.php, used for live (AJAX) archive search.
$filter = $_GET['filter'] ?? 'movie';
$search = trim($_GET['q'] ?? '');

$sql = "SELECT * FROM media_items WHERE 1=1";
$params = [];

if ($filter === 'movie' || $filter === 'game') {
    $sql .= " AND type = :type";
    $params['type'] = $filter;
}

if ($search !== '') {
    $sql .= " AND title LIKE :search";
    $params['search'] = "%$search%";
}

$sql .= " ORDER BY title ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

$totalMovies = $pdo->query("SELECT COUNT(*) FROM media_items WHERE type='movie'")->fetchColumn();
$totalGames = $pdo->query("SELECT COUNT(*) FROM media_items WHERE type='game'")->fetchColumn();

ob_start();
?>
<section id="itemsGrid" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5 items-start">
<?php
foreach ($items as $item) {
    include __DIR__ . '/../includes/card.php';
}
?>
</section>
<?php
$html = ob_get_clean();

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'success' => true,
    'html' => $html,
    'count' => count($items),
    'totalMovies' => (int)$totalMovies,
    'totalGames' => (int)$totalGames,
]);