<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/helpers.php';

$input = json_decode(file_get_contents('php://input'), true);
$title = trim($input['title'] ?? '');
$status = trim($input['status'] ?? '');
$type = $input['type'] ?? 'game';

if ($title === '' || !in_array($type, ['movie', 'game'])) {
    echo json_encode(['success' => false, 'message' => 'Missing title or type.']);
    exit;
}

if (mb_strlen($status) > 255) {
    $status = mb_substr($status, 0, 255);
}
$status = $status === '' ? null : $status;

try {
    $pdo = getDB();

    // Skip if a row with the exact same title already exists (avoid duplicate imports)
    $check = $pdo->prepare("SELECT id FROM media_items WHERE title = :title LIMIT 1");
    $check->execute(['title' => $title]);
    if ($check->fetch()) {
        echo json_encode(['success' => true, 'skipped' => true, 'title' => $title]);
        exit;
    }

    $info = fetchMediaInfo($title, $type);

    $finalTitle = $info['title'] ?? $title;
    $posterUrl = $info['poster_url'] ?? null;
    $externalLink = $info['external_link'] ?? null;
    $overview = $info['overview'] ?? null;
    $releaseDate = $info['release_date'] ?? null;
    $rating = $info['rating'] ?? null;
    $externalId = $info['external_id'] ?? null;

    $stmt = $pdo->prepare("
        INSERT INTO media_items (title, type, status, poster_url, external_link, overview, release_date, rating, external_id)
        VALUES (:title, :type, :status, :poster_url, :external_link, :overview, :release_date, :rating, :external_id)
    ");
    $stmt->execute([
        'title' => $title, // keep the title as typed/pasted by the user, not the matched result's title
        'type' => $type,
        'status' => $status,
        'poster_url' => $posterUrl,
        'external_link' => $externalLink,
        'overview' => $overview,
        'release_date' => $releaseDate,
        'rating' => $rating,
        'external_id' => $externalId,
    ]);

    echo json_encode([
        'success' => true,
        'skipped' => false,
        'title' => $title,
        'found' => $info !== null,
        'poster_url' => $posterUrl,
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
