<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/xlsx-reader.php';

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'No file was uploaded, or the upload failed.']);
    exit;
}

$tmpPath = $_FILES['file']['tmp_name'];
$originalName = $_FILES['file']['name'];
$ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

try {
    if ($ext === 'xlsx') {
        $rows = readXlsxFirstSheet($tmpPath);
    } elseif ($ext === 'csv') {
        $rows = readCsvRows($tmpPath);
    } else {
        echo json_encode(['success' => false, 'message' => 'Please upload a .xlsx or .csv file.']);
        exit;
    }

    if (empty($rows)) {
        echo json_encode(['success' => false, 'message' => 'The file appears to be empty.']);
        exit;
    }

    // Assume first row is the header
    $header = array_map('trim', $rows[0]);
    $dataRows = array_slice($rows, 1);

    // Drop fully empty rows
    $dataRows = array_values(array_filter($dataRows, function ($r) {
        foreach ($r as $cell) {
            if (trim((string) $cell) !== '') return true;
        }
        return false;
    }));

    // Determine the real last used column: the furthest column index that has
    // a non-empty header OR at least one non-empty value anywhere in the data.
    // This drops trailing empty columns some spreadsheets report (e.g. formatted
    // but never filled), which would otherwise show up as "Column 3", "Column 4"...
    $lastUsedCol = -1;
    foreach ($header as $i => $h) {
        if (trim((string) $h) !== '') $lastUsedCol = max($lastUsedCol, $i);
    }
    foreach ($dataRows as $row) {
        foreach ($row as $i => $cell) {
            if (trim((string) $cell) !== '') $lastUsedCol = max($lastUsedCol, $i);
        }
    }

    if ($lastUsedCol >= 0) {
        $header = array_slice($header, 0, $lastUsedCol + 1);
        $dataRows = array_map(function ($row) use ($lastUsedCol) {
            $row = array_slice($row, 0, $lastUsedCol + 1);
            // pad in case this row was shorter than the widest one
            while (count($row) < $lastUsedCol + 1) $row[] = '';
            return $row;
        }, $dataRows);
    }

    // Cap preview/import size to something sane
    if (count($dataRows) > 2000) {
        $dataRows = array_slice($dataRows, 0, 2000);
    }

    echo json_encode([
        'success' => true,
        'header' => $header,
        'rows' => $dataRows,
        'row_count' => count($dataRows),
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
