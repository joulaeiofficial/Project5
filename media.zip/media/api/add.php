<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/helpers.php';

$input = json_decode(file_get_contents('php://input'), true);
$title = trim($input['title'] ?? '');
$status = trim($input['status'] ?? '');
$picked = $input['picked'] ?? null; // Item selected from the live search dropdown

if ($title === '') {
    echo json_encode(['success' => false, 'message' => 'Please enter a title.']);
    exit;
}

// Type (movie/game) is only known once the user picks a specific search result,
// since there's no separate type selector anymore.
if (!is_array($picked) || !in_array($picked['type'] ?? '', ['movie', 'game'])) {
    echo json_encode(['success' => false, 'message' => 'Please pick a result from the search dropdown first.']);
    exit;
}

$type = $picked['type'];

// Status is free text the user types themselves (e.g. "Finished", "8/10", "Replaying").
if (mb_strlen($status) > 255) {
    $status = mb_substr($status, 0, 255);
}
$status = $status === '' ? null : $status;

try {
    $pdo = getDB();

    $info = $picked;

    $finalTitle = $info['title'] ?? $title;
    $posterUrl = $info['poster_url'] ?? null;
    $externalLink = $info['external_link'] ?? null;
    $overview = $info['overview'] ?? null;
    $releaseDate = $info['release_date'] ?? null;
    $rating = $info['rating'] ?? null;
    $externalId = $info['external_id'] ?? null;

    $stmt = $pdo->prepare("
        INSERT INTO media_items (title, type, status, poster_url, external_link, overview, release_date, rating, external_id)
        VALUES (:title, :type, :status, :poster_url, :external_link, :overview, :release_date, :rating, :external_id)
    ");
    $stmt->execute([
        'title' => $finalTitle,
        'type' => $type,
        'status' => $status,
        'poster_url' => $posterUrl,
        'external_link' => $externalLink,
        'overview' => $overview,
        'release_date' => $releaseDate,
        'rating' => $rating,
        'external_id' => $externalId,
    ]);

    $newId = $pdo->lastInsertId();

    echo json_encode([
        'success' => true,
        'item' => [
            'id' => $newId,
            'title' => $finalTitle,
            'poster_url' => $posterUrl,
        ],
        'message' => null,
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
