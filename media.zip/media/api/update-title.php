<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';

$input = json_decode(file_get_contents('php://input'), true);
$id = intval($input['id'] ?? 0);
$title = trim($input['title'] ?? '');

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid ID.']);
    exit;
}

if ($title === '') {
    echo json_encode(['success' => false, 'message' => 'Title cannot be empty.']);
    exit;
}

if (mb_strlen($title) > 255) {
    $title = mb_substr($title, 0, 255);
}

try {
    $pdo = getDB();
    $stmt = $pdo->prepare("UPDATE media_items SET title = :title WHERE id = :id");
    $stmt->execute(['title' => $title, 'id' => $id]);

    echo json_encode(['success' => true, 'title' => $title]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
