<?php
/**
 * Minimal, dependency-free XLSX reader.
 * Reads the first worksheet of a .xlsx file and returns rows as arrays of strings.
 * Works using PHP's built-in ZipArchive + SimpleXML (both included in default PHP/XAMPP builds).
 */

function readXlsxFirstSheet($filePath) {
    if (!class_exists('ZipArchive')) {
        throw new Exception('The PHP "zip" extension is not enabled. Enable it in php.ini (extension=zip) and restart Apache.');
    }

    $zip = new ZipArchive();
    if ($zip->open($filePath) !== true) {
        throw new Exception('Could not open the uploaded file as .xlsx (is it a valid Excel file?).');
    }

    // 1. Shared strings (text cells reference an index into this table)
    $sharedStrings = [];
    $sharedXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($sharedXml !== false) {
        $sst = simplexml_load_string($sharedXml);
        if ($sst !== false) {
            foreach ($sst->si as $si) {
                // A shared string can contain multiple runs (<r><t>...</t></r>) or a plain <t>
                if (isset($si->t)) {
                    $sharedStrings[] = (string) $si->t;
                } else {
                    $parts = [];
                    foreach ($si->r as $r) {
                        $parts[] = (string) $r->t;
                    }
                    $sharedStrings[] = implode('', $parts);
                }
            }
        }
    }

    // 2. Find the first sheet's path via workbook.xml + relationships
    $sheetPath = 'xl/worksheets/sheet1.xml'; // sane default
    $workbookXml = $zip->getFromName('xl/workbook.xml');
    $relsXml = $zip->getFromName('xl/_rels/workbook.xml.rels');
    if ($workbookXml !== false && $relsXml !== false) {
        $wb = simplexml_load_string($workbookXml);
        $rels = simplexml_load_string($relsXml);
        if ($wb !== false && $rels !== false && isset($wb->sheets->sheet[0])) {
            $firstSheet = $wb->sheets->sheet[0];
            $rid = (string) $firstSheet->attributes('r', true)['id'];
            foreach ($rels->Relationship as $rel) {
                if ((string) $rel['Id'] === $rid) {
                    $target = (string) $rel['Target'];
                    if (strpos($target, '/') === 0) {
                        // Absolute path within the archive, e.g. "/xl/worksheets/sheet1.xml"
                        $sheetPath = ltrim($target, '/');
                    } else {
                        // Relative to xl/, e.g. "worksheets/sheet1.xml"
                        $sheetPath = 'xl/' . $target;
                    }
                    break;
                }
            }
        }
    }

    $sheetXml = $zip->getFromName($sheetPath);
    if ($sheetXml === false) {
        $zip->close();
        throw new Exception('Could not find worksheet data inside the file.');
    }

    $sheet = simplexml_load_string($sheetXml);
    $zip->close();

    if ($sheet === false || !isset($sheet->sheetData->row)) {
        return [];
    }

    $rows = [];
    foreach ($sheet->sheetData->row as $row) {
        $rowData = [];
        $maxCol = 0;
        $cells = [];

        foreach ($row->c as $c) {
            $ref = (string) $c['r']; // e.g. "B7"
            $colLetters = preg_replace('/[0-9]/', '', $ref);
            $colIndex = xlsxColumnLetterToIndex($colLetters);
            $maxCol = max($maxCol, $colIndex);

            $type = (string) $c['t'];
            $value = '';

            if (isset($c->v)) {
                $rawValue = (string) $c->v;
                if ($type === 's') {
                    // shared string
                    $idx = (int) $rawValue;
                    $value = $sharedStrings[$idx] ?? '';
                } elseif ($type === 'inlineStr' && isset($c->is->t)) {
                    $value = (string) $c->is->t;
                } else {
                    $value = $rawValue;
                }
            } elseif (isset($c->is->t)) {
                $value = (string) $c->is->t;
            }

            $cells[$colIndex] = $value;
        }

        for ($i = 0; $i <= $maxCol; $i++) {
            $rowData[] = $cells[$i] ?? '';
        }
        $rows[] = $rowData;
    }

    return $rows;
}

function xlsxColumnLetterToIndex($letters) {
    $letters = strtoupper($letters);
    $index = 0;
    for ($i = 0; $i < strlen($letters); $i++) {
        $index = $index * 26 + (ord($letters[$i]) - ord('A') + 1);
    }
    return $index - 1; // 0-based
}

/**
 * Very small CSV reader wrapper, used as a fallback for .csv uploads.
 */
function readCsvRows($filePath) {
    $rows = [];
    if (($handle = fopen($filePath, 'r')) !== false) {
        // Strip BOM if present
        $bom = fread($handle, 3);
        if ($bom !== "\xEF\xBB\xBF") {
            rewind($handle);
        }
        while (($data = fgetcsv($handle)) !== false) {
            $rows[] = $data;
        }
        fclose($handle);
    }
    return $rows;
}
