<?php
/** @var array $item */
$isMovie = $item['type'] === 'movie';
$badgeColor = $isMovie ? 'bg-amber text-ink' : 'bg-rust text-bone';
$badgeLabel = $isMovie ? 'Movie' : 'Game';
$statusLabel = trim($item['status'] ?? '');
?>
<div class="item-card-wrapper">
  <div class="item-card group relative bg-panel border border-black/40 shadow-[0_0_0_1px_rgba(255,255,255,0.12)] rounded-xl overflow-hidden hover:border-amber/50 transition-all flex flex-col" data-type="<?= $item['type'] ?>">
    <div class="card-poster bg-ink relative overflow-hidden">
      <?php if (!empty($item['poster_url'])):
        // First few cards load immediately (above the fold); the rest lazy-load.
        $GLOBALS['__card_i'] = ($GLOBALS['__card_i'] ?? 0) + 1;
        $eager  = $GLOBALS['__card_i'] <= 5;
        $srcset = imgSrcset($item['poster_url']);
      ?>
        <img src="<?= htmlspecialchars(imgSrc($item['poster_url'], 320)) ?>"
          <?php if ($srcset): ?>srcset="<?= htmlspecialchars($srcset) ?>"
          sizes="(min-width:1024px) 20vw, (min-width:768px) 25vw, (min-width:640px) 33vw, 50vw"<?php endif; ?>
          alt="<?= htmlspecialchars($item['title']) ?>" width="320" height="480"
          class="w-full h-full object-cover" decoding="async"
          <?= $eager ? 'fetchpriority="high"' : 'loading="lazy"' ?>>
      <?php else: ?>
        <div class="w-full h-full flex items-center justify-center text-4xl text-bone/20">
          <?= $isMovie ? '🎬' : '🎮' ?>
        </div>
      <?php endif; ?>

      <span class="absolute top-2 right-2 text-[10px] font-bold px-2 py-1 rounded-full <?= $badgeColor ?>">
        <?= $badgeLabel ?>
      </span>

      <button onclick="deleteItem(<?= $item['id'] ?>, this, '<?= htmlspecialchars(addslashes($item['title'])) ?>')"
        class="absolute top-2 left-2 w-7 h-7 rounded-full bg-black/60 text-bone/70 hover:bg-rust hover:text-white opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center text-sm">
        ✕
      </button>
    </div>

    <div class="p-3">
      <!-- Fixed-height, scrollable title box: long titles scroll internally instead of clamping/growing the card. Scrollbar hidden. -->
      <div class="title-block relative" data-title-block data-item-id="<?= $item['id'] ?>">
        <div class="h-9 overflow-y-auto scrollbar-hide pr-1 mb-1">
          <h3 class="title-display font-bold text-sm leading-tight break-words cursor-pointer hover:opacity-80 transition-opacity"
            data-raw-value="<?= htmlspecialchars($item['title']) ?>"
            onclick="startEditTitle(this)"><?= htmlspecialchars($item['title']) ?></h3>
        </div>
        <div class="title-edit hidden mb-1">
          <textarea class="title-textarea scrollbar-hide w-full h-9 bg-ink border border-white/15 rounded-lg px-2 py-1 text-sm text-bone placeholder:text-bone/30 focus:outline-none focus:border-amber resize-none overflow-y-auto"><?= htmlspecialchars($item['title']) ?></textarea>
          <div class="flex gap-2 mt-1.5">
            <button type="button" class="title-save-btn flex-1 bg-amber text-ink text-[11px] font-bold rounded-lg py-1.5 hover:bg-amber/90 transition-colors" onclick="saveTitle(this)">Save</button>
            <button type="button" class="title-cancel-btn flex-1 border border-white/15 text-bone/60 text-[11px] font-bold rounded-lg py-1.5 hover:border-white/30 transition-colors" onclick="cancelEditTitle(this)">Cancel</button>
          </div>
        </div>
      </div>
      <!-- Year line: always reserved (empty when missing) so every card's info block is the same height -->
      <p class="mono text-[10px] text-bone/40 mb-2 h-3 leading-none"><?= !empty($item['release_date']) ? htmlspecialchars(substr($item['release_date'], 0, 4)) : '' ?></p>
      <!-- Link line: always reserved (empty when missing) for the same reason -->
      <div class="mono text-[11px] h-4 leading-none">
        <?php if (!empty($item['external_link'])): ?>
          <a href="<?= htmlspecialchars($item['external_link']) ?>" target="_blank"
            class="text-amber hover:underline inline-flex items-center gap-1">
            <?= externalLinkLabel($item['external_link']) ?>
          </a>
        <?php endif; ?>
      </div>
    </div>

    <!-- Note section: same card, divided by a border. Small fixed-height box; long notes scroll internally with the scrollbar hidden, instead of stretching the card. -->
    <div class="border-t border-white/10 p-2.5 flex flex-col" data-note-block data-item-id="<?= $item['id'] ?>">
      <div class="relative">
        <p class="note-display max-h-4 overflow-y-auto scrollbar-hide leading-[16px] pr-3 text-[12px] text-amber/90 font-medium break-words whitespace-pre-line cursor-pointer hover:opacity-80 transition-opacity <?= $statusLabel === '' ? 'italic text-bone/30' : '' ?>"
           data-raw-value="<?= htmlspecialchars($statusLabel) ?>"
           onclick="startEditNote(this)"><?= $statusLabel !== '' ? htmlspecialchars($statusLabel) : '+ Add note' ?></p>
        <!-- Shown by JS only when the note has more lines than fit; hidden while editing. Tells the user there's more to scroll to. -->
        <span class="note-more-indicator hidden absolute top-1/2 -translate-y-1/2 right-0 text-[10px] font-bold leading-none text-amber pointer-events-none select-none">•••</span>
      </div>

      <div class="note-edit hidden">
        <textarea class="note-textarea scrollbar-hide w-full h-9 bg-ink border border-white/15 rounded-lg px-2 py-1.5 text-[12px] text-bone placeholder:text-bone/30 focus:outline-none focus:border-amber resize-none overflow-y-auto" placeholder="Your notes..."><?= htmlspecialchars($statusLabel) ?></textarea>
        <div class="flex gap-2 mt-1.5">
          <button type="button" class="note-save-btn flex-1 bg-amber text-ink text-[11px] font-bold rounded-lg py-1.5 hover:bg-amber/90 transition-colors" onclick="saveNote(this)">Save</button>
          <button type="button" class="note-cancel-btn flex-1 border border-white/15 text-bone/60 text-[11px] font-bold rounded-lg py-1.5 hover:border-white/30 transition-colors" onclick="cancelEditNote(this)">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>