<?php
/**
 * Database layer: a single SQLite file inside the project (data/media.sqlite)
 * plus automatic backups.
 *
 * Why SQLite instead of XAMPP's MySQL: MySQL keeps its files in
 * C:\xampp\mysql\data (outside the project). A crash, a power cut while it is
 * running, a XAMPP reinstall/upgrade or a wiped data folder makes the whole
 * database disappear. Here the database is one visible file next to the code,
 * so it can be copied, backed up and restored like any other file.
 *
 * Protections:
 *  - synchronous=FULL + rollback journal  -> survives power loss / crashes
 *  - one verified backup per day (only when the DB has data, so an empty DB can
 *    never push good backups out of the rotation)
 *  - backup right before any bulk delete / import / restore
 *  - corrupted file is detected on open, quarantined and the newest good
 *    backup is restored automatically
 *  - optional mirror copy of every backup to another folder/drive
 */

// ---------- small helpers ----------

function dbEnsureDirs() {
    foreach ([DATA_DIR, BACKUP_DIR] as $dir) {
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
    }
    // Block direct web access to the database and backups (Apache 2.4 + 2.2).
    $ht = DATA_DIR . '/.htaccess';
    if (!file_exists($ht)) {
        @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n");
    }
    $idx = DATA_DIR . '/index.html';
    if (!file_exists($idx)) @file_put_contents($idx, '');
}

/** True if the file starts with the SQLite magic header. */
function dbFileLooksValid($path) {
    if (!is_file($path) || filesize($path) < 100) return false;
    $h = @file_get_contents($path, false, null, 0, 16);
    return $h === "SQLite format 3\0";
}

/** Open a SQLite file, run quick_check, return item count or null if broken. */
function dbInspectFile($path) {
    if (!dbFileLooksValid($path)) return null;
    try {
        $p = new PDO('sqlite:' . $path);
        $p->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $ok = $p->query('PRAGMA quick_check')->fetchColumn();
        if ($ok !== 'ok') return null;
        $has = $p->query("SELECT name FROM sqlite_master WHERE type='table' AND name='media_items'")->fetchColumn();
        if (!$has) return null;
        $n = (int)$p->query('SELECT COUNT(*) FROM media_items')->fetchColumn();
        $p = null;
        return $n;
    } catch (Throwable $e) {
        return null;
    }
}

function dbInitSchema(PDO $pdo) {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS media_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            type TEXT NOT NULL CHECK (type IN ('movie','game')),
            status TEXT DEFAULT NULL,
            poster_url TEXT DEFAULT NULL,
            external_link TEXT DEFAULT NULL,
            overview TEXT DEFAULT NULL,
            release_date TEXT DEFAULT NULL,
            rating TEXT DEFAULT NULL,
            external_id TEXT DEFAULT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_media_type ON media_items(type)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_media_title ON media_items(title)");
}

// ---------- connection ----------

/** Drop the cached connection (needed before replacing the file on restore). */
function closeDB() {
    $GLOBALS['__mt_pdo'] = null;
}

function getDB() {
    if (!empty($GLOBALS['__mt_pdo'])) return $GLOBALS['__mt_pdo'];

    try {
        dbEnsureDirs();

        // 1) Existing file that is damaged -> quarantine it and restore.
        $recovered = null;
        if (file_exists(DB_FILE) && filesize(DB_FILE) > 0 && dbInspectFile(DB_FILE) === null) {
            $recovered = dbRecoverFromCorruption();
        }

        $isNew = !file_exists(DB_FILE) || filesize(DB_FILE) === 0;

        $pdo = new PDO('sqlite:' . DB_FILE, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT => 10, // wait up to 10s if another request is writing
        ]);
        $pdo->exec('PRAGMA synchronous = FULL');
        $pdo->exec('PRAGMA journal_mode = DELETE');

        dbInitSchema($pdo);
        $GLOBALS['__mt_pdo'] = $pdo;

        // 2) Brand-new database: pull data over from the old MySQL one if present.
        if ($isNew) {
            dbImportFromMySQL($pdo);
        }

        // 3) Daily verified backup (cheap check first).
        dbDailyBackup($pdo);

        return $pdo;
    } catch (Throwable $e) {
        die('Database error: ' . htmlspecialchars($e->getMessage()));
    }
}

// ---------- backups ----------

function dbBackupFiles() {
    $files = glob(BACKUP_DIR . '/media-*.sqlite') ?: [];
    rsort($files); // names start with a timestamp -> newest first
    return $files;
}

/** Parse a backup filename into its parts. */
function dbBackupInfo($path) {
    $name = basename($path);
    if (!preg_match('/^media-(\d{8})-(\d{6})-([a-z0-9-]+)-n(\d+)\.sqlite$/', $name, $m)) return null;
    $dt = DateTime::createFromFormat('Ymd His', $m[1] . ' ' . $m[2]);
    return [
        'name' => $name,
        'path' => $path,
        'time' => $dt ? $dt->format('Y-m-d H:i:s') : '',
        'reason' => $m[3],
        'items' => (int)$m[4],
        'size' => @filesize($path) ?: 0,
    ];
}

/**
 * Create a verified backup of the current database.
 * Returns the backup path, or null if it was skipped/failed.
 */
function createBackup($reason = 'manual', $allowEmpty = true) {
    $pdo = getDB();
    $reason = preg_replace('/[^a-z0-9-]/', '', strtolower($reason)) ?: 'manual';
    $count = (int)$pdo->query('SELECT COUNT(*) FROM media_items')->fetchColumn();
    if ($count === 0 && !$allowEmpty) return null;

    dbEnsureDirs();
    $mk = function () use ($reason, $count) {
        return BACKUP_DIR . '/media-' . date('Ymd-His') . '-' . $reason . '-n' . $count . '.sqlite';
    };
    $target = $mk();
    while (file_exists($target)) { // two backups within the same second
        usleep(250000);
        $target = $mk();
    }

    $ok = false;
    try {
        // VACUUM INTO writes a consistent, compact copy even while the DB is open.
        $pdo->exec('VACUUM INTO ' . $pdo->quote($target));
        $ok = true;
    } catch (Throwable $e) {
        $ok = @copy(DB_FILE, $target); // fallback for very old SQLite builds
    }

    if (!$ok || dbInspectFile($target) !== $count) {
        @unlink($target);
        return null;
    }

    // Optional mirror to another drive/folder.
    if (defined('BACKUP_MIRROR_DIR') && BACKUP_MIRROR_DIR !== '') {
        if (!is_dir(BACKUP_MIRROR_DIR)) @mkdir(BACKUP_MIRROR_DIR, 0775, true);
        @copy($target, rtrim(BACKUP_MIRROR_DIR, '/\\') . '/' . basename($target));
    }

    dbRotateBackups();
    return $target;
}

/** Keep the newest N daily backups and the newest N of everything else. */
function dbRotateBackups() {
    $keep = ['daily' => 30, 'other' => 40];
    $seen = ['daily' => 0, 'other' => 0];
    foreach (dbBackupFiles() as $f) {
        $info = dbBackupInfo($f);
        if (!$info) continue;
        $grp = $info['reason'] === 'daily' ? 'daily' : 'other';
        if (++$seen[$grp] > $keep[$grp]) @unlink($f);
    }
}

function dbDailyBackup(PDO $pdo) {
    $marker = BACKUP_DIR . '/.last-daily';
    $today = date('Y-m-d');
    if (@file_get_contents($marker) === $today) return;
    // Never back up an empty DB as "daily": it must not replace good history.
    $path = createBackup('daily', false);
    if ($path !== null || (int)$pdo->query('SELECT COUNT(*) FROM media_items')->fetchColumn() === 0) {
        @file_put_contents($marker, $today);
    }
}

/** Damaged DB file: move it aside and restore the newest healthy backup. */
function dbRecoverFromCorruption() {
    $bad = DATA_DIR . '/media.corrupt-' . date('Ymd-His') . '.sqlite';
    @rename(DB_FILE, $bad);
    @unlink(DB_FILE . '-journal');
    // Prefer the newest backup that actually contains data, then any healthy one.
    $healthy = [];
    foreach (dbBackupFiles() as $f) {
        $n = dbInspectFile($f);
        if ($n !== null) $healthy[] = [$f, $n];
    }
    usort($healthy, function ($a, $b) { return ($b[1] > 0) <=> ($a[1] > 0); }); // stable in PHP 8: keeps newest-first within groups
    foreach ($healthy as [$f]) {
        if (@copy($f, DB_FILE)) {
            @file_put_contents(DATA_DIR . '/RECOVERED.txt',
                date('c') . " - database file was damaged; restored from " . basename($f) .
                "; damaged copy kept as " . basename($bad) . "\n", FILE_APPEND);
            return $f;
        }
    }
    return null; // no usable backup -> a fresh empty DB will be created
}

/** Restore a named backup. Current DB is backed up first. */
function restoreBackup($name) {
    if (!preg_match('/^media-[0-9-]+-[a-z0-9-]+-n\d+\.sqlite$/', $name)) {
        throw new RuntimeException('Invalid backup name');
    }
    $src = BACKUP_DIR . '/' . $name;
    if (dbInspectFile($src) === null) throw new RuntimeException('Backup file is missing or damaged');

    createBackup('before-restore', false);
    closeDB();
    $tmp = DB_FILE . '.restore-tmp';
    if (!@copy($src, $tmp)) throw new RuntimeException('Could not copy backup');
    if (!@rename($tmp, DB_FILE)) {          // Windows can refuse to rename over an existing file
        @unlink(DB_FILE);
        if (!@rename($tmp, DB_FILE)) throw new RuntimeException('Could not replace database file');
    }
    @unlink(DB_FILE . '-journal');
}

// ---------- one-time import from the old MySQL database ----------

/**
 * Copies rows from the legacy MySQL database (if reachable) that are not
 * already present (matched by type + title). Returns number of rows added.
 */
function dbImportFromMySQL(PDO $pdo) {
    if (!defined('LEGACY_MYSQL_IMPORT') || !LEGACY_MYSQL_IMPORT) return 0;
    if (!in_array('mysql', PDO::getAvailableDrivers(), true)) return 0;
    try {
        $my = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 3,
        ]);
        $rows = $my->query('SELECT * FROM media_items ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return 0; // MySQL not running / database gone: nothing to import
    }
    if (!$rows) return 0;

    $exists = $pdo->prepare('SELECT 1 FROM media_items WHERE type = :t AND title = :ti LIMIT 1');
    $ins = $pdo->prepare('INSERT INTO media_items
        (title, type, status, poster_url, external_link, overview, release_date, rating, external_id, created_at)
        VALUES (:title, :type, :status, :poster_url, :external_link, :overview, :release_date, :rating, :external_id, :created_at)');
    $added = 0;
    $pdo->beginTransaction();
    foreach ($rows as $r) {
        $exists->execute(['t' => $r['type'], 'ti' => $r['title']]);
        if ($exists->fetchColumn()) continue;
        $ins->execute([
            'title' => $r['title'], 'type' => $r['type'], 'status' => $r['status'] ?? null,
            'poster_url' => $r['poster_url'] ?? null, 'external_link' => $r['external_link'] ?? null,
            'overview' => $r['overview'] ?? null, 'release_date' => $r['release_date'] ?? null,
            'rating' => $r['rating'] ?? null, 'external_id' => $r['external_id'] ?? null,
            'created_at' => $r['created_at'] ?? date('Y-m-d H:i:s'),
        ]);
        $added++;
    }
    $pdo->commit();
    if ($added > 0) createBackup('after-mysql-import');
    return $added;
}
