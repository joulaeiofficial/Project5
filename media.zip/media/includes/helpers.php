<?php

/**
 * Append a debug line to debug.log when DEBUG_EXTERNAL_APIS is on.
 * $data can be a string or array; arrays are dumped compactly.
 * Long strings are trimmed so the log stays readable.
 */
function debugLog($label, $data = null) {
    if (!defined('DEBUG_EXTERNAL_APIS') || !DEBUG_EXTERNAL_APIS) return;

    $line = '[' . date('Y-m-d H:i:s') . '] ' . $label;
    if ($data !== null) {
        if (is_array($data)) {
            $data = json_encode($data, JSON_UNESCAPED_SLASHES);
        }
        if (is_string($data) && mb_strlen($data) > 1500) {
            $data = mb_substr($data, 0, 1500) . '... [truncated, ' . mb_strlen($data) . ' chars total]';
        }
        $line .= ' | ' . $data;
    }
    @file_put_contents(DEBUG_LOG_PATH, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function httpGet($url, $retries = 2, $debugLabel = null) {
    for ($attempt = 0; $attempt <= $retries; $attempt++) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // avoid SSL cert issues on local XAMPP
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);   // max time to establish connection
        curl_setopt($ch, CURLOPT_TIMEOUT, 12);          // max time for the whole request
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (MediaTracker Local App)');
        $response = curl_exec($ch);
        $err = curl_error($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);

        if ($debugLabel) {
            debugLog("GET [$debugLabel] attempt " . ($attempt + 1), [
                'url' => $url,
                'final_url' => $finalUrl,
                'http_code' => $httpCode,
                'curl_errno' => $errno,
                'response_len' => $response !== false ? strlen($response) : 0,
                'response_preview' => $response !== false ? substr($response, 0, 400) : null,
            ]);
        }

        if (!$errno && $response !== false) {
            return $response;
        }

        error_log("cURL error [$errno]: $err | URL: $url | attempt " . ($attempt + 1));

        if ($attempt < $retries) {
            usleep(300000); // wait 300ms before retrying
        }
    }
    return null;
}

function httpPostJson($url, $payload, $retries = 2, $debugLabel = null) {
    $body = json_encode($payload);
    for ($attempt = 0; $attempt <= $retries; $attempt++) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // avoid SSL cert issues on local XAMPP
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
        curl_setopt($ch, CURLOPT_TIMEOUT, 12);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (MediaTracker Local App)');
        $response = curl_exec($ch);
        $err = curl_error($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($debugLabel) {
            debugLog("POST [$debugLabel] attempt " . ($attempt + 1), [
                'url' => $url,
                'payload' => $payload,
                'http_code' => $httpCode,
                'curl_errno' => $errno,
                'response_len' => $response !== false ? strlen($response) : 0,
                'response_preview' => $response !== false ? substr($response, 0, 600) : null,
            ]);
        }

        if (!$errno && $response !== false) {
            return $response;
        }

        error_log("cURL POST error [$errno]: $err | URL: $url | attempt " . ($attempt + 1));

        if ($attempt < $retries) {
            usleep(300000);
        }
    }
    return null;
}

/**
 * Detect a pasted TMDb URL (e.g. https://www.themoviedb.org/movie/36657-x-men/
 * or https://www.themoviedb.org/tv/1396-breaking-bad) and pull out its
 * media type ('movie' or 'tv') and numeric id, ignoring the trailing slug.
 * Returns null if the string isn't a recognizable TMDb URL.
 */
function parseTMDbUrl($input) {
    $input = trim($input);
    if (!preg_match('#themoviedb\.org(?:/[a-z-]+)?/(movie|tv)/(\d+)#i', $input, $m)) {
        return null;
    }
    return ['media_type' => strtolower($m[1]), 'id' => $m[2]];
}

/**
 * Fetch a single movie/tv item directly from TMDb by id (used when the user
 * pastes a TMDb URL into search instead of typing a title).
 */
function fetchTMDbById($mediaType, $id) {
    $url = TMDB_BASE_URL . "/" . $mediaType . "/" . $id . "?api_key=" . TMDB_API_KEY . "&language=en-US";
    $response = httpGet($url, 2, 'tmdb-by-id');
    if (!$response) return null;

    $item = json_decode($response, true);
    // TMDb returns {"success":false,"status_code":...} for a bad/unknown id
    if (empty($item) || (isset($item['success']) && $item['success'] === false) || !isset($item['id'])) {
        return null;
    }

    $isTv = $mediaType === 'tv';
    $title_ = $isTv ? ($item['name'] ?? '') : ($item['title'] ?? '');
    if ($title_ === '') return null;
    $releaseDate = $isTv ? ($item['first_air_date'] ?? '') : ($item['release_date'] ?? '');

    return [
        'title' => $title_ . ($isTv ? ' (TV Series)' : ''),
        'poster_url' => !empty($item['poster_path']) ? TMDB_IMAGE_URL . $item['poster_path'] : null,
        'overview' => $item['overview'] ?? '',
        'release_date' => $releaseDate,
        'rating' => isset($item['vote_average']) ? round($item['vote_average'], 1) : null,
        'external_id' => $item['id'],
        'external_link' => "https://www.themoviedb.org/" . $mediaType . "/" . $item['id'],
        'source' => 'tmdb',
        'type' => 'movie', // both movie and tv are tracked as 'movie' type in this app
    ];
}

/**
 * Search a single movie or TV show on TMDb and return its main info.
 * Uses /search/multi so series (e.g. "Arcane") are found too, not just movies.
 */
function searchMovieTMDb($title) {
    $url = TMDB_BASE_URL . "/search/multi?api_key=" . TMDB_API_KEY .
           "&language=en-US&query=" . urlencode($title);

    $response = httpGet($url);
    if (!$response) return null;

    $data = json_decode($response, true);
    if (empty($data['results'])) return null;

    $item = null;
    foreach ($data['results'] as $r) {
        if (($r['media_type'] ?? '') === 'movie' || ($r['media_type'] ?? '') === 'tv') {
            $item = $r;
            break;
        }
    }
    if ($item === null) return null;

    $mediaType = $item['media_type'];
    $isTv = $mediaType === 'tv';
    $title_ = $isTv ? ($item['name'] ?? $title) : ($item['title'] ?? $title);
    $releaseDate = $isTv ? ($item['first_air_date'] ?? '') : ($item['release_date'] ?? '');
    $id = $item['id'] ?? null;

    return [
        'title' => $title_ . ($isTv ? ' (TV Series)' : ''),
        'poster_url' => !empty($item['poster_path']) ? TMDB_IMAGE_URL . $item['poster_path'] : null,
        'overview' => $item['overview'] ?? '',
        'release_date' => $releaseDate,
        'rating' => isset($item['vote_average']) ? round($item['vote_average'], 1) : null,
        'external_id' => $id,
        'external_link' => $id ? "https://www.themoviedb.org/" . $mediaType . "/" . $id : null,
        'source' => 'tmdb',
    ];
}

/**
 * Search a game on RAWG (https://rawg.io/apidocs)
 */
function searchGameRAWG($title) {
    $url = RAWG_BASE_URL . "/games?key=" . RAWG_API_KEY .
           "&search=" . urlencode($title) . "&page_size=1";
    $response = httpGet($url);
    if (!$response) return null;

    $data = json_decode($response, true);
    if (empty($data['results'])) return null;

    $game = $data['results'][0];
    $gameId = $game['id'] ?? null;

    return [
        'title' => $game['name'] ?? $title,
        'poster_url' => $game['background_image'] ?? null,
        'overview' => '', // RAWG's search results don't include a description; needs a details call
        'release_date' => $game['released'] ?? '',
        'rating' => isset($game['rating']) ? round($game['rating'], 1) : null,
        'external_id' => $gameId,
        'external_link' => $gameId ? "https://rawg.io/games/" . $gameId : null,
        'source' => 'rawg',
    ];
}

function fetchMediaInfo($title, $type) {
    if ($type === 'movie') {
        return searchMovieTMDb($title);
    } elseif ($type === 'game') {
        return searchGameRAWG($title);
    }
    return null;
}

/**
 * Search TMDb for multiple results (used for live search).
 * Uses the /search/multi endpoint so both movies and TV shows are found
 * (e.g. "Arcane" is a series, not a movie), skipping "person" results.
 */
function searchMoviesListTMDb($title, $limit = 6) {
    $url = TMDB_BASE_URL . "/search/multi?api_key=" . TMDB_API_KEY .
           "&language=en-US&query=" . urlencode($title);
    $response = httpGet($url);
    if (!$response) return [];

    $data = json_decode($response, true);
    if (empty($data['results'])) return [];

    $out = [];
    foreach ($data['results'] as $item) {
        $mediaType = $item['media_type'] ?? '';
        if ($mediaType !== 'movie' && $mediaType !== 'tv') continue;

        $isTv = $mediaType === 'tv';
        $title_ = $isTv ? ($item['name'] ?? $title) : ($item['title'] ?? $title);
        $releaseDate = $isTv ? ($item['first_air_date'] ?? '') : ($item['release_date'] ?? '');
        $id = $item['id'] ?? null;

        $out[] = [
            'title' => $title_ . ($isTv ? ' (TV Series)' : ''),
            'poster_url' => !empty($item['poster_path']) ? TMDB_IMAGE_URL . $item['poster_path'] : null,
            'overview' => $item['overview'] ?? '',
            'release_date' => $releaseDate,
            'rating' => isset($item['vote_average']) ? round($item['vote_average'], 1) : null,
            'external_id' => $id,
            'external_link' => $id ? "https://www.themoviedb.org/" . $mediaType . "/" . $id : null,
        ];

        if (count($out) >= $limit) break;
    }
    return $out;
}

/**
 * Search RAWG for multiple game results (used for live search).
 */
function searchGamesListRAWG($title, $limit = 6) {
    $url = RAWG_BASE_URL . "/games?key=" . RAWG_API_KEY .
           "&search=" . urlencode($title) . "&page_size=" . $limit;
    $response = httpGet($url);
    if (!$response) return [];

    $data = json_decode($response, true);
    if (empty($data['results'])) return [];

    $out = [];
    foreach (array_slice($data['results'], 0, $limit) as $game) {
        $gameId = $game['id'] ?? null;
        $out[] = [
            'title' => $game['name'] ?? $title,
            'poster_url' => $game['background_image'] ?? null,
            'overview' => '',
            'release_date' => $game['released'] ?? '',
            'rating' => isset($game['rating']) ? round($game['rating'], 1) : null,
            'external_id' => $gameId,
            'external_link' => $gameId ? "https://rawg.io/games/" . $gameId : null,
            'source' => 'rawg',
        ];
    }
    return $out;
}

/**
 * Search games (RAWG is the only game source).
 */
function searchGamesList($title, $limit = 6) {
    return searchGamesListRAWG($title, $limit);
}

function searchMediaList($title, $type, $limit = 6) {
    if ($type === 'movie') {
        return searchMoviesListTMDb($title, $limit);
    } elseif ($type === 'game') {
        return searchGamesList($title, $limit);
    }
    return [];
}

/**
 * Human-readable label + link icon for an item's external_link, used on the
 * cards. Derived from the URL's domain (rather than a stored "source"
 * column) so it works for existing rows too.
 */
function externalLinkLabel($url) {
    if (!$url) return null;
    if (strpos($url, 'rawg.io') !== false) return 'RAWG ↗';
    if (strpos($url, 'themoviedb.org') !== false) return 'TMDb ↗';
    return 'Link ↗';
}


// =====================================================================
// Image optimization
// Posters are downloaded once, cover-cropped to 2:3, resized and saved as
// WebP in cache/img/. After that the page links straight to the small
// static file (served with a 1-year cache header), so nothing is fetched
// from TMDb / RAWG again.
// =====================================================================
define('IMG_CACHE_DIR', __DIR__ . '/../cache/img');
define('IMG_CACHE_URL', 'cache/img');                 // relative to the project root
const IMG_ALLOWED_WIDTHS = [80, 160, 320, 480, 640];
const IMG_ALLOWED_HOST_SUFFIXES = [
    'tmdb.org', 'rawg.io',
];

/** Only fetch images from known poster hosts (prevents img.php being abused as an open proxy). */
function imgIsAllowedUrl($url) {
    if (!is_string($url) || !preg_match('#^https://#i', $url)) return false;
    $host = strtolower((string)parse_url($url, PHP_URL_HOST));
    if ($host === '') return false;
    foreach (IMG_ALLOWED_HOST_SUFFIXES as $suffix) {
        if ($host === $suffix || substr($host, -strlen($suffix) - 1) === '.' . $suffix) return true;
    }
    return false;
}

function imgExt() {
    return function_exists('imagewebp') ? 'webp' : 'jpg';
}

function imgCachePath($url, $width) {
    return IMG_CACHE_DIR . '/' . substr(sha1($url), 0, 24) . '-' . (int)$width . '.' . imgExt();
}

/** URL to put in <img src>: the static cached file if it exists, otherwise img.php (which creates it). */
function imgSrc($url, $width = 320) {
    if (empty($url)) return null;
    if (!imgIsAllowedUrl($url) || !function_exists('imagecreatetruecolor')) return $url;
    $path = imgCachePath($url, $width);
    if (is_file($path)) return IMG_CACHE_URL . '/' . basename($path);
    return 'img.php?w=' . (int)$width . '&u=' . rawurlencode($url);
}

/** srcset string for 1x/1.5x-2x screens, or null when the URL isn't optimizable. */
function imgSrcset($url, array $widths = [320, 480]) {
    if (empty($url) || !imgIsAllowedUrl($url) || !function_exists('imagecreatetruecolor')) return null;
    $parts = [];
    foreach ($widths as $w) $parts[] = imgSrc($url, $w) . ' ' . $w . 'w';
    return implode(', ', $parts);
}

/** Ask the image host for a smaller original when it supports that (saves the first download). */
function imgDownscaleSource($url) {
    if (strpos($url, 'image.tmdb.org/t/p/') !== false) {
        return preg_replace('#/t/p/(?:w\d+|h\d+|original)/#', '/t/p/w780/', $url);
    }
    if (preg_match('#^(https://media\.rawg\.io/media)/(games|screenshots)/#', $url, $m)) {
        return preg_replace('#^https://media\.rawg\.io/media/#', 'https://media.rawg.io/media/resize/1280/-/', $url);
    }
    return $url;
}

/**
 * Download one poster, cover-crop it to 2:3, and save a WebP (JPEG if GD has no WebP) per requested width.
 * Returns ['paths' => [width => file], 'src_bytes' => int|null] or null on failure.
 * src_bytes is null when everything was already cached (nothing was downloaded).
 */
function imgProcess($url, $widths) {
    $widths = array_values(array_unique(array_map('intval', (array)$widths)));
    if (!$widths || array_diff($widths, IMG_ALLOWED_WIDTHS)) return null;
    if (!imgIsAllowedUrl($url) || !function_exists('imagecreatetruecolor')) return null;

    $paths = [];
    $missing = [];
    foreach ($widths as $w) {
        $paths[$w] = imgCachePath($url, $w);
        if (!is_file($paths[$w])) $missing[] = $w;
    }
    if (!$missing) return ['paths' => $paths, 'src_bytes' => null];

    if (!is_dir(IMG_CACHE_DIR)) @mkdir(IMG_CACHE_DIR, 0775, true);

    // --- download (try the smaller source first, fall back to the original URL)
    $data = false;
    foreach (array_values(array_unique([imgDownscaleSource($url), $url])) as $candidate) {
        $ch = curl_init($candidate);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_MAXREDIRS       => 3,
            CURLOPT_PROTOCOLS       => CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_SSL_VERIFYPEER  => false,   // same as httpGet(): avoids cert issues on local XAMPP
            CURLOPT_SSL_VERIFYHOST  => false,
            CURLOPT_CONNECTTIMEOUT  => 8,
            CURLOPT_TIMEOUT         => 20,
            CURLOPT_USERAGENT       => 'Mozilla/5.0 (MediaTracker Local App)',
            CURLOPT_ENCODING        => '',
            CURLOPT_NOPROGRESS      => false,
            // abort anything bigger than 15 MB
            CURLOPT_PROGRESSFUNCTION => function ($r, $dlTotal, $dlNow) { return $dlNow > 15 * 1024 * 1024 ? 1 : 0; },
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body !== false && $code >= 200 && $code < 300 && strlen($body) > 100) { $data = $body; break; }
    }
    if ($data === false) return null;

    $src = @getimagesizefromstring($data) ? @imagecreatefromstring($data) : false;
    if (!$src) return null;
    $srcBytes = strlen($data);
    unset($data);

    $sw = imagesx($src);
    $sh = imagesy($src);

    // --- cover-crop to a 2:3 poster (same result the page's object-cover would show)
    $ratio = 2 / 3;
    if ($sw / $sh > $ratio) { $cropH = $sh; $cropW = (int)round($sh * $ratio); }
    else                    { $cropW = $sw; $cropH = (int)round($sw / $ratio); }
    $cropX = (int)floor(($sw - $cropW) / 2);
    $cropY = (int)floor(($sh - $cropH) / 2);

    $isWebp = imgExt() === 'webp';
    foreach ($missing as $w) {
        $outW = min($w, $cropW);               // never upscale
        $outH = (int)round($outW / $ratio);
        $out  = imagecreatetruecolor($outW, $outH);
        if ($isWebp) {
            imagealphablending($out, false);
            imagesavealpha($out, true);
            imagefill($out, 0, 0, imagecolorallocatealpha($out, 0, 0, 0, 127));
        } else {
            imagefill($out, 0, 0, imagecolorallocate($out, 18, 18, 18));
        }
        imagecopyresampled($out, $src, 0, 0, $cropX, $cropY, $outW, $outH, $cropW, $cropH);

        // write atomically so a half-written file is never served
        $tmp = $paths[$w] . '.' . getmypid() . '.tmp';
        if ($isWebp) {
            $ok = imagewebp($out, $tmp, 80);
        } else {
            imageinterlace($out, true);
            $ok = imagejpeg($out, $tmp, 82);
        }
        imagedestroy($out);
        if (!$ok || !@rename($tmp, $paths[$w])) { @unlink($tmp); imagedestroy($src); return null; }
    }
    imagedestroy($src);

    return ['paths' => $paths, 'src_bytes' => $srcBytes];
}

/** Small thumbnail URL for the live-search dropdown (not cached locally; those results are mostly never added). */
function thumbUrl($url) {
    if (empty($url)) return $url;
    if (strpos($url, 'image.tmdb.org/t/p/') !== false) {
        return preg_replace('#/t/p/(?:w\d+|h\d+|original)/#', '/t/p/w154/', $url);
    }
    if (preg_match('#^https://media\.rawg\.io/media/(games|screenshots)/#', $url)) {
        return preg_replace('#^https://media\.rawg\.io/media/#', 'https://media.rawg.io/media/resize/200/-/', $url);
    }
    return $url;
}
