<?php
// Pre-generates optimized posters for every item already in the database,
// so the first page load after upgrading is already fast.
// Run once:  http://localhost/media-tracker/warm-cache.php   (or: php warm-cache.php)
// Safe to run again - already cached images are skipped.
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/helpers.php';

set_time_limit(0);
$cli = PHP_SAPI === 'cli';
if (!$cli) { header('Content-Type: text/plain; charset=utf-8'); @ini_set('output_buffering', 'off'); }

if (!function_exists('imagecreatetruecolor')) {
    exit("PHP GD extension is not enabled. In php.ini uncomment 'extension=gd', restart Apache, run again.\n");
}

$pdo  = getDB();
$rows = $pdo->query("SELECT id, title, poster_url FROM media_items WHERE poster_url IS NOT NULL AND poster_url <> ''")->fetchAll();
echo count($rows) . " posters to check...\n";
@ob_flush(); flush();

$done = $skipped = $failed = 0;
$srcTotal = $outTotal = 0;
foreach ($rows as $r) {
    if (!imgIsAllowedUrl($r['poster_url'])) { $skipped++; continue; }
    $res = imgProcess($r['poster_url'], [320, 480]);   // one download, both sizes
    $ok = (bool)$res;
    if ($res) {
        foreach ($res['paths'] as $f) $outTotal += filesize($f);
        if ($res['src_bytes'] !== null) $srcTotal += $res['src_bytes'];
    }
    if ($ok) { $done++; echo "OK   #{$r['id']} {$r['title']}\n"; }
    else     { $failed++; echo "FAIL #{$r['id']} {$r['title']}\n"; }
    @ob_flush(); flush();
}

printf("\nDone: %d optimized, %d skipped (unknown host), %d failed.\n", $done, $skipped, $failed);
if ($srcTotal > 0) {
    printf("Downloaded originals: %.1f MB  ->  cached copies (both sizes): %.1f MB\n", $srcTotal / 1048576, $outTotal / 1048576);
}
