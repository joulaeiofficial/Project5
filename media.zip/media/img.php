<?php
// Image optimizer / cache. Usage: img.php?u=<encoded poster url>&w=320
// Creates cache/img/<hash>-<w>.webp once, then serves it. Page templates link
// directly to the cached static file after the first request (see imgSrc()).
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/helpers.php';

$url = (string)($_GET['u'] ?? '');
$w   = (int)($_GET['w'] ?? 320);

if (!imgIsAllowedUrl($url)) {
    http_response_code(400);
    exit;
}
if (!in_array($w, IMG_ALLOWED_WIDTHS, true)) $w = 320;

$res = imgProcess($url, [$w]);

if (!$res) {
    // Couldn't optimize (host down, GD missing...): send the visitor to the original image
    // so the poster still shows, and don't let the browser remember the failure for long.
    header('Cache-Control: no-store');
    header('Location: ' . $url, true, 302);
    exit;
}

$path  = $res['paths'][$w];
$etag  = '"' . md5_file($path) . '"';
$mtime = filemtime($path);
header('Content-Type: ' . (imgExt() === 'webp' ? 'image/webp' : 'image/jpeg'));
header('Cache-Control: public, max-age=31536000, immutable');
header('ETag: ' . $etag);
header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) {
    http_response_code(304);
    exit;
}
header('Content-Length: ' . filesize($path));
readfile($path);
